#include "include.h"

SYSTEM_WHETHER_TYPE_VARIABLES_Typedef enPILE_NEED_PAI_ZA_FLAG = YES; //�Ƿ���Ҫ����
SYSTEM_WHETHER_TYPE_VARIABLES_Typedef WAITTING_FOR_PAI_ZA_FLAG = NO; //�Ƿ���������

SYSTEM_WHETHER_TYPE_VARIABLES_Typedef enPILE_WORKING_FLAG = NO; //��ѹ���״̬

SYSTEM_WHETHER_TYPE_VARIABLES_Typedef g_ePumpDecAtBeginningFlag = NO;
SYSTEM_WHETHER_TYPE_VARIABLES_Typedef g_ePumpDecOverFlag = NO;
SYSTEM_TIME_Typedef g_stPumpAdjustTimeForLiquidPress = {0xFF, 0xFF, 0xFFFF};
SYSTEM_TIME_Typedef m_stHydrpgFanAdjustLastTime = {0xFF, 0xFF, 0xFFFF};
uint16_t u16CurrentAirOutCycle = 0, u16CurrentAirOutTimeA_Cycle = 0;

void OFF_WaittingPaiZaFlag()
{
    WAITTING_FOR_PAI_ZA_FLAG = NO;
}
void SetPileWorkingFlag()
{
    enPILE_WORKING_FLAG = YES;
    SetStackFanSpd(50);
//  printf("48V break from SetPileWorkingFlag()!<---\r\n");
    Output48VSwitchON;
    SetPaiQiParametersFromCurrentPower();
    TIM2_PaiQiStart();
}
SYSTEM_WHETHER_TYPE_VARIABLES_Typedef GetPileWorkingFlag()
{
    return enPILE_WORKING_FLAG;
}

void Running()
{
    SYSTEM_TIME_Typedef m_stAIR_LOW_START_TIME, m_stAIR_LOW_TIME_CHECK;
//  SYSTEM_TIME_Typedef m_stPUMP_LAST_ADJUST_TIME_FOR_LIQUID_PRESS = {0xFF, 0xFF, 0xFFFF};
//  SYSTEM_TIME_Typedef m_stPUMP_LAST_ADJUST_TIME_FOR_TEMP = {0xFF, 0xFF, 0xFFFF};

//  SYSTEM_TIME_Typedef m_stTEMP_120S_TIME_CHECK = {0xFF, 0xFF, 0xFFFF};
//  SYSTEM_TIME_Typedef m_stLIQUID_PRESS_30S_TIME_CHECK = {0xFF, 0xFF, 0xFFFF};
    SYSTEM_TIME_Typedef m_stPumpAdjustCurrentTime;
    SYSTEM_TIME_Typedef m_stHydrpgFanAdjustCurrentTime;
    SYSTEM_WHETHER_TYPE_VARIABLES_Typedef m_FanAdOverFlag = NO, FirstTimeRunningFlag = YES;
    uint16_t m_u16FanAdjustWaitTime = 0;
    double m_TEMP1;
    float m_LIQUID_PRESS;
    double m_AIR_PRESS_1;
    double m_PILE_TEMP;
//  double m_CurrentPower;


    WAITTING_FOR_PAI_ZA_FLAG = NO;
    enPILE_WORKING_FLAG = NO;
    g_ePumpDecOverFlag = NO;


    CAN_MsgRefresh(CAN_TXMSG1, CANTXMSG1_RUN_LED, GREEN);
    CAN_MsgRefresh(CAN_TXMSG1, CANTXMSG1_HEATER_LED, GREEN);
    printf("begin to running!<-----\r\n");

    AirInON;

    if(GetSystemRunningTimes() > 2) {
        enPILE_NEED_PAI_ZA_FLAG = NO;
    } else {
        enPILE_NEED_PAI_ZA_FLAG = YES;
    }

    while(GetRunningStatus() == RUNNING) {

        m_TEMP1 = GetRefromRoomTemp();//��ȡ�������¶�

        //�¶��Ƿ���ھ��������¶�
        if(m_TEMP1 < (float)stREFORMINGROOM_TEMP_TABLE.LowerLimitRunningAlarmTemp) {
            //�ж��Ƿ��Ѵ��������ҵ��±���
            if(OFF == GetAlarmStatu(REFORMINGROOM_LOW_TEMP_ALARM)) {
                AlarmCmd(REFORMINGROOM_LOW_TEMP_ALARM, ON);//���������ҵ��¾���
//              BeepON;
            }

        } else { //if( m_TEMP1 >= (float)stREFORMINGROOM_TEMP_TABLE.LowerLimitRunningAlarmTemp)//�¶��Ƿ��ѻָ������±�����������
            if(ON == GetAlarmStatu(REFORMINGROOM_LOW_TEMP_ALARM)) {
                AlarmCmd(REFORMINGROOM_LOW_TEMP_ALARM, OFF);
            }
        }

        //�ж������ң��¶�1���Ƿ�����¶ȱ�������,���ǣ�������¾�������������
        if(m_TEMP1 > (float)stREFORMINGROOM_TEMP_TABLE.UpperLimitRunningAlarmTemp) {
            //�ж��Ƿ��Ѵ��������Ҹ��±���
            if(OFF == GetAlarmStatu(REFORMINGROOM_HIGH_TEMP_ALARM)) {
                AlarmCmd(REFORMINGROOM_HIGH_TEMP_ALARM, ON);//���������Ҹ��¾���
            }
        } else { 
            if(ON == GetAlarmStatu(REFORMINGROOM_HIGH_TEMP_ALARM)) {
                AlarmCmd(REFORMINGROOM_HIGH_TEMP_ALARM, OFF);
            }
        }

   

        //����Һѹ��������ֵ��������
        m_LIQUID_PRESS = GetSourceANA_Value(LIQUID_PRESS);

        if(m_LIQUID_PRESS >= g_u8PumpAdjLqdPrssTab) {
            if(g_ePumpDecOverFlag == NO) {
                if(g_ePumpDecAtBeginningFlag == NO) {
                    g_stPumpAdjustTimeForLiquidPress = GetSystemTime();
                    g_ePumpDecAtBeginningFlag = YES;
                } else {
                    m_stPumpAdjustCurrentTime = GetSystemTime();

                    if((((m_stPumpAdjustCurrentTime.hour - g_stPumpAdjustTimeForLiquidPress.hour) * 60
                            + m_stPumpAdjustCurrentTime.minute - g_stPumpAdjustTimeForLiquidPress.minute) * 60
                            + m_stPumpAdjustCurrentTime.second - g_stPumpAdjustTimeForLiquidPress.second)
                            >= 1) {
                        PumpSpeedDec();
                        g_stPumpAdjustTimeForLiquidPress = GetSystemTime();//ˢ�±Ƚ�ʱ��
                    } else {
                    }//���������һѭ���м�����ȡʱ��

                    if(GetPumpSpeed() <= g_u8PumpRunSpdAfterAdj) {
                        SetHydrgPumpSpd(g_u8PumpRunSpdAfterAdj);
                        g_ePumpDecOverFlag = YES;   //��������
                        g_stPumpAdjustTimeForLiquidPress.hour = 0xFFFF;
                        g_stPumpAdjustTimeForLiquidPress.minute = 0xFF;
                        g_stPumpAdjustTimeForLiquidPress.second = 0xFF;//ʱ�临λ
                    } else {
                    }//�����������
                }
            } else {
            }
        } else {
        }

        //�������л�1�ְ��Ӻ��ٶȵ���
        if(FirstTimeRunningFlag == YES) {
            m_stHydrpgFanAdjustLastTime = GetSystemTime();
            FirstTimeRunningFlag = NO;
        } else {
            if(NO == m_FanAdOverFlag) {
                m_stHydrpgFanAdjustCurrentTime = GetSystemTime();

                if((((m_stHydrpgFanAdjustCurrentTime.hour - m_stHydrpgFanAdjustLastTime.hour) * 60
                        + m_stHydrpgFanAdjustCurrentTime.minute - m_stHydrpgFanAdjustLastTime.minute) * 60
                        + m_stHydrpgFanAdjustCurrentTime.second - m_stHydrpgFanAdjustLastTime.second)
                        >= 1) {
                    m_u16FanAdjustWaitTime++;
                    m_stHydrpgFanAdjustLastTime = GetSystemTime();//ˢ�±Ƚ�ʱ��

                    if(m_u16FanAdjustWaitTime >= 120) {
                        if(m_u16FanAdjustWaitTime % 5 == 0) {
                            if(GetHydrgFanCtrlSpd() < 100) {//130    //����
                                HydrgFanSpdInc();
//                            if(GetHydrgFanCtrlSpd() >50) {//130   //����
//                                HydrgFanSpdDec();
                            } else {
                                m_FanAdOverFlag = YES;
                                m_stHydrpgFanAdjustLastTime.hour = 0xFFFF;
                                m_stHydrpgFanAdjustLastTime.minute = 0xFF;
                                m_stHydrpgFanAdjustLastTime.second = 0xFF;//ʱ�临λ
                            }
                        }
                    }
                }
            } else {
                //������ɺ�ֹͣ����
            }
        }

        //��������в���
        m_AIR_PRESS_1 = GetSourceANA_Value(AIR_PRESS_1);

        //�жϵ���Ƿ��ڹ���
        if(YES == enPILE_WORKING_FLAG) {

            //�ж��Ƿ��Ѿ�������ѹ���;���
            if(OFF == GetAlarmStatu(AIR_PRESS_LOW_ALARM)) {

                //����ѹ���ͣ������𾯱���־
                if(m_AIR_PRESS_1 < 10) { //10KPa
//                  printf("air press is too low!<---\r\n");
                    AlarmCmd(AIR_PRESS_LOW_ALARM, ON);
                    m_stAIR_LOW_START_TIME = GetSystemTime();//��¼��ѹ��������ʱ��
                }
            } else if(m_AIR_PRESS_1 >= 10) { //���Ѿ�������ѹ���;��������ж��Ƿ��ѻָ�����
                printf("air press has back to normal from low statu!<--\r\n");
                AlarmCmd(AIR_PRESS_LOW_ALARM, OFF);
            } else {
                //����ѹδ�ָ����ж��Ƿ��ѳ���30��
                m_stAIR_LOW_TIME_CHECK = GetSystemTime();

                if((((m_stAIR_LOW_TIME_CHECK.hour - m_stAIR_LOW_START_TIME.hour) * 60
                        + m_stAIR_LOW_TIME_CHECK.minute - m_stAIR_LOW_START_TIME.minute) * 60
                        + m_stAIR_LOW_TIME_CHECK.second - m_stAIR_LOW_START_TIME.second)
                        >= 30) {
                    printf("air press has been low for 30s!<--\r\n");
                    enPILE_WORKING_FLAG = NO;
                    SoftPowerOff();
                    SetRunningStatus(KEEPINGWARM);
                    break;//ֱ������������������β��while��ѭ���ڵ�KeepingWarm()
                }
            }

            //�����ѹ
            if(m_AIR_PRESS_1 <= 65) { //65KPa
                if(ON == GetAlarmStatu(AIR_PRESS_HIGH_ALARM)) {
//                  printf("air press has back to normal from high statu!<--\r\n");
                    AlarmCmd(AIR_PRESS_HIGH_ALARM, OFF);
                }
            } else if(m_AIR_PRESS_1 < 75) { //65KPa
                if(OFF == GetAlarmStatu(AIR_PRESS_HIGH_ALARM)) {
//                      printf("air press is too high(below 75)!<--\r\n");
//                      BeepON;
                    AlarmCmd(AIR_PRESS_HIGH_ALARM, ON);
                }
            } else {
//                  printf("air press is above 75!<--\r\n");
//                  BeepON;
                enPILE_WORKING_FLAG = NO;

                if(OFF == GetAlarmStatu(AIR_PRESS_HIGH_ALARM)) {
                    AlarmCmd(AIR_PRESS_HIGH_ALARM, ON);
                }

//                  SoftPowerOff();
//                  SetRunningStatus(KEEPINGWARM);
//                  StartTIM6(ELECTRIC_OFF_DELAY_5000, 5000);//5���رշ�������;
//                  break;
            }

        } else {
            if(m_AIR_PRESS_1 >= 40) {
//              printf("air press above 50KPa!<----\r\n");
                if(enPILE_NEED_PAI_ZA_FLAG == YES) {
//                  printf("start to paiza!<----\r\n");
                    AirInON;
                    AirExON;
                    enPILE_NEED_PAI_ZA_FLAG = NO;
                    WAITTING_FOR_PAI_ZA_FLAG = YES;
                    StartTIM6(PAI_ZA_FOR_5000, 5000);//5���򿪷���������
                } else {
//                  printf("not need to restart paiza!<----\r\n");
                    //ֱ���������ӣ������ӵȴ��Ѿ����
                    if(WAITTING_FOR_PAI_ZA_FLAG == NO) {
//                      printf("paiza has already finish!pile begin to work!<---\r\n");
                        SetPileWorkingFlag();
                    } else {
//                      printf("the paiza has not finish!<----\r\n");
                        //�ȴ��������
                    }

                }

            } else {
//              printf("the air press is not arrive 50KPa!<---\r\n");
            }
        }


        //���ݵ���¶ȵ��ڵ�ѷ����ٶ�
        m_PILE_TEMP = GetSourceANA_Value(PILE_TEMP);

        if(enPILE_WORKING_FLAG == YES) {
            Systick_Idelay_ms(20);  //��ֹPWM�����ڹ��죬��ʱ�����һ��PWM����

            if(m_PILE_TEMP <= 25) {
                SetStackFanSpd(50);
            } else if(m_PILE_TEMP <= 40) {
                SetStackFanSpd(50 + (uint8_t)((m_PILE_TEMP - 25) * 12 / 4));
            } else if(m_PILE_TEMP <= 50) {
                SetStackFanSpd(95 + (uint8_t)((m_PILE_TEMP - 40) * 23 / 5));
            } else if(m_PILE_TEMP <= 60) {
                SetStackFanSpd(141 + (uint8_t)((m_PILE_TEMP - 50) * 15 / 3));
            } else {
                SetStackFanSpd(200);
            }
        } else {
            SetStackFanSpd(0);
        }

        if(m_PILE_TEMP <= 68) {
            if(ON == GetAlarmStatu(PILE_TEMP_HIGH_ALARM)) {
                BeepOFF;
                AlarmCmd(PILE_TEMP_HIGH_ALARM, OFF);
            }
        } else if(m_PILE_TEMP <= 70) {
            if(OFF == GetAlarmStatu(PILE_TEMP_HIGH_ALARM)) {
                BeepON;
                printf("Stack temp abrove protect line!");
                AlarmCmd(PILE_TEMP_HIGH_ALARM, ON);
            }
        } else {
            BeepON;

            if(OFF == GetAlarmStatu(PILE_TEMP_HIGH_ALARM)) {
                BeepON;
                AlarmCmd(PILE_TEMP_HIGH_ALARM, ON);
            }

            SetRunningStatus(KEEPINGWARM);
            break;//ֱ����������ȡ�¶�ֵ�����������β��while��ѭ���ڵ�KeepingWarm()
        }
    }

    WAITTING_FOR_PAI_ZA_FLAG = NO;
    enPILE_WORKING_FLAG = NO;
    CAN_MsgRefresh(CAN_TXMSG1, CANTXMSG1_RUN_LED, BLUE);
    CAN_MsgRefresh(CAN_TXMSG1, CANTXMSG1_HEATER_LED, BLUE);
}


