#include "include.h"

void SoftPowerOff()
{
    HeaterOFF;
    IgniterOFF;
    MagneticValve1OFF;
    MagneticValve2OFF;
//  Output48VSwitchOFF;
    ReformRoomKeepWarmOFF;
    PumpStop();

    /*
        if(GetRunningStatus() == KEEPINGWARM)
        {
            StopHydrgFan();
        }
        else if((GetRunningStatus() == RUNNING) || (GetRunningStatus() == PRERUNNING_DIAN_HUO_ONE) || (GetRunningStatus() == PRERUNNING_DIAN_HUO_TWO))
    */
    if(GetRunningStatus() != WAITTINGCOMMAND) {
        Delay3MinStopHydrgFan();
    }

}
