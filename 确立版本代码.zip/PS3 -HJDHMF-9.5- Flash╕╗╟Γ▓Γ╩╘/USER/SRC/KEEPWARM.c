#include "include.h"

void    KeepingWarm(void)
{
//  uint16_t m_TEMP1;
    SoftPowerOff();
#ifdef INSIDE_KEEPWARM_MODE
    SetRunningStatus(KEEPINGWARM);

    while(GetRunningStatus() == KEEPINGWARM) {
        m_TEMP1 = GetRefromRoomTemp();

        if(m_TEMP1 < stREFORMINGROOM_TEMP_TABLE.LowerLimitHeatKeeping) {
            ReformRoomKeepWarmON;
        }

        if(m_TEMP1 > stREFORMINGROOM_TEMP_TABLE.UpperLimitHeatKeeping) {
            ReformRoomKeepWarmOFF;
        }
    }

#else
    SetRunningStatus(WAITTINGCOMMAND);
#endif
}

