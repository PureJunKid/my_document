#ifndef __PRESTART_H
#define __PRESTART_H


//void SetStartMode(SYSTEM_START_MODE_Typedef m_NEW_MODE_STATU);
void PreRunning(void);
DIAN_HUO_CHECK_STATU_Typedef DianHuoFirstTimeCheck(float m_DianHuoCheckTable1, float GoToNextStepTempTable1, uint8_t maxtrytime, uint8_t m_CheckDelayTimeFlag);
DIAN_HUO_CHECK_STATU_Typedef DianHuoSecondTimeCheck(float m_DianHuoCheckTable2, float GoToNextStepTempTable2, uint8_t maxtrytime, uint8_t m_CheckDelayTimeFlag);
DIAN_HUO_CHECK_STATU_Typedef RestartDianHuoCheck(uint8_t maxtrytime);

u16 GetStartRemainSencond(void);



#endif




