#ifndef __SYSTEM_STATU_PARAMETERS_H
#define __SYSTEM_STATU_PARAMETERS_H

typedef struct {
    uint8_t     second;
    uint8_t     minute;
    uint32_t    hour;
} SYSTEM_TIME_Typedef;

typedef enum {
    FRONT_HALF,
    LATTER_HALF
} SYSTEM_TIME_REFRESH_FLAG_Typedef;

typedef enum {
    PRERUNNING_TEMP_BELOW_100 = 0,
    PRERUNNING_TEMP_100_TO_300,
    PRERUNNING_TEMP_300_TO_390,
    PRERUNNING_TEMP_390_TO_465,
    PRERUNNING_TEMP_ABOVE_465
} SYSTEM_PRERUNNING_TEMP_FLAG_Typedef;

typedef enum {
    WAITTINGCOMMAND = 0,
    PRERUNNING_DIAN_HUO_ONE,
    PRERUNNING_DIAN_HUO_TWO,
    RUNNING,
    KEEPINGWARM,
} SYSTEM_RUNNING_STATUS_Typedef;

typedef enum {
    ON = 0,
    OFF
} SYSTEM_SWITCH_VARIABLES_STATU_Typedef;

typedef enum {
    NO = 0,
    YES = !0
} SYSTEM_WHETHER_TYPE_VARIABLES_Typedef;

typedef enum {
    PILE_TEMP_HIGH_ALARM = 0,   //��Ѹ��¾���
    PILE_VOLT_LOW_ALARM,        //��Ѹ�ѹ����

    WATER_LOW_ALARM,                //��Һλ����

    AIR_PRESS_LOW_ALARM,        //����ѹ����
    AIR_PRESS_HIGH_ALARM,       //����ѹ����

    REFORMINGROOM_LOW_TEMP_ALARM,       //�����ҵ��¾���
    REFORMINGROOM_HIGH_TEMP_ALARM,      //�����Ҹ��¾���
} SYSTEM_ALARM_KIND_Typedef;

typedef struct {
    SYSTEM_SWITCH_VARIABLES_STATU_Typedef   FlagStatu;//����״̬
    SYSTEM_TIME_Typedef         HoldTime;//�������𱣳�ʱ��
} ALARM_Paremeter_Typedef;

typedef enum {
    DIRECT = 0,
    WAITTING = !DIRECT
} SYSTEM_START_MODE_Typedef;

typedef enum {
    NOTCHECK = 0,
    CHECKING,
    FAILED,
    PASS
} DIAN_HUO_CHECK_STATU_Typedef;

typedef struct {
    float H2_Press;         //��Ӧ������ѹǿ

    float ActualPower;  //�������Բ�����ʵ�ʹ���

    float DIV_H2H_Press;    //ƥ�������ѹ��
    float DIV_H2O_Press;   //ƥ�������ѹ��
    float DIV_O2O_Press;    //ƥ�������ѹ��
} SYSTEM_ACTUAL_H2_AND_POWER_Typedef;

/*
typedef struct
{
    float RequiedPower; //Ŀ�깦��

    //ϵͳ��������
    float DIV_H2O_PRESS_MAX;   //����ѹ���ֵ
    float DIV_LIQUID_PRESS_MAX;   //���Һѹ
    float REFROM_TEMP_MAX;        //�����������
    float POLE_TEMP_MAX;       //��������
}REQUIRED_POWER_AND_LIMIT_PARAMETERS_Typedef;
*/
void UpdateSystemTimes(void);
SYSTEM_TIME_Typedef GetSystemTime(void);


void ResetH2MakeTimeThisTime(void);
SYSTEM_TIME_Typedef GetH2MakeTimeThisTime(void);
SYSTEM_TIME_Typedef GetH2MakeTimeTotal(void);

void ResetRunningTimes(void);
void SystemRunningTimesInc(void);
uint32_t GetSystemRunningTimes(void);

SYSTEM_ACTUAL_H2_AND_POWER_Typedef GetActualH2ForPowerAndParameters(void);

void SetRunningStatus(SYSTEM_RUNNING_STATUS_Typedef m_enNewStatu);
SYSTEM_RUNNING_STATUS_Typedef GetRunningStatus(void);

void AlarmCmd(SYSTEM_ALARM_KIND_Typedef m_enSystemAlarmKind, SYSTEM_SWITCH_VARIABLES_STATU_Typedef m_enNewStatu);
SYSTEM_SWITCH_VARIABLES_STATU_Typedef GetAlarmStatu(SYSTEM_ALARM_KIND_Typedef m_enSystemAlarmKind);
SYSTEM_TIME_Typedef GetAlarmHoldTime(SYSTEM_ALARM_KIND_Typedef m_enSystemAlarmKind);

void AlarmHoldTimeRefresh(SYSTEM_ALARM_KIND_Typedef m_enSystemAlarmKind);

void RefreshSystemTotalPower(void);
double GetSystemTotalPower(void);
void SetAheadRunningFlag(SYSTEM_WHETHER_TYPE_VARIABLES_Typedef m_NES_STATU);
SYSTEM_WHETHER_TYPE_VARIABLES_Typedef GetAheadRunningFlag(void);

void SetExternalScreenUpdateStatu(SYSTEM_WHETHER_TYPE_VARIABLES_Typedef);
SYSTEM_WHETHER_TYPE_VARIABLES_Typedef GetExternalScreenUpdateStatu(void);


#endif

