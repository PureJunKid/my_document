#ifndef _PARAMETERS_H_
#define _PARAMETERS_H_


typedef struct {
    u16 StartTempLevel;//K1-1

    u16 LowerLimitHeatKeeping;//K1-2
    u16 UpperLimitHeatKeeping;//K1-3

    u16 LowerLimitRunningAlarmTemp;//K1-4
    u16 UpperLimitRunningAlarmTemp;//k1-5

    u16 LowerLimitPowerDown;//K1-6
    u16 UpperLimitPowerDown;//k1-7

    u16 ForPumpAdjustLine1;//K1-8
    u16 ForPumpAdjustLine2;//K1-9
    u16 ForPumpAdjustLine3;//K1-10
    u16 ForPumpAdjustLine4;//K1-11
    u16 ForPumpAdjustLine5;//K1-12
    u16 ForPumpAdjustLine6;//K1-13

} REFORMINGROOM_TEMP_LINES_Typedef;

typedef struct {
    u16 HeatingRodTemp;//K2-1
    u16 FlameTemp_1;      //K3-1
    u16 FlameTemp_2;  //K3-2
} HEAT_AND_FLAME_TEMP_Typedef;

typedef struct {
    u16 ForPumpAdjustLine1;//Y1
    u16 ForPumpAdjustLine2;//Y2
    u16 ForPumpAdjustLine3;//Y3
    u16 ForPumpAdjustLine4;//Y4
} HYDRAULIC_PRESSURE_LINES_Typedef;

typedef struct {
    u16 ReformingRoom;//K1
    u16 HeatingRod;//K2
    u16 Flame;
} SYSTEM_TEMPS_Typedef;

typedef struct {
    u16 TimeForWaittingAdjust;//G-Tx
    u16 Ratio;//Gx
} BELOWER_ADJUST_PARAMETER_Typedef;

typedef struct {
    u16 HoldTimeWhenHeating;//D1
    u16 HoldTimeWhenRunning;//D2
    u16 CheckTime;//D3

    //D1 <= D2, D1 <= D3

} TIMES_FOR_IGNITIONCHECK_Typedef;
/*
typedef enum
{
    //0-4
    PUMP_PRESSURE_FAST_HEATING = 0,//��ѹB1
    TEMP_PRESSURE_RUNNING_STABLE,//B2,�ȶ�����״̬��ѹ

    TEMP_PRESSURE_TEMP_STATUS_1,//B3,K1-8<�¶�1<K1-9
    TEMP_PRESSURE_TEMP_STATUS_2,//B4,K1-9<�¶�1<K1-10
    TEMP_PRESSURE_TEMP_STATUS_3,//B5,K1-10<�¶�1<K1-11

    //5-9
    TEMP_PRESSURE_TEMP_STATUS_4,//B6,K1-11<�¶�1<K1-12
    TEMP_PRESSURE_TEMP_STATUS_5,//B7,K1-12<�¶�1<K1-13
    TEMP_PRESSURE_TEMP_STATUS_6,//B8,�¶�1>K1-13

    PUMP_PRESSURE_PRESS_STATUS_1,//B9,Һѹ1<Y2
    PUMP_PRESSURE_PRESS_STATUS_2,//B10,Y2<Һѹ1<Y3

    //10��11
    PUMP_PRESSURE_PRESS_STATUS_3,//B11,Y3<Һѹ1<Y4
    PUMP_PRESSURE_PRESS_STATUS_4//B12,Һѹ1>Y4
}PUMP_PRESSURE_OUTPUT_KIND_Typedef;
*/
typedef struct {
    u16 Power;
    u16 TimeForAirOutCycle;//ȼ�ϵ�ض�Ӧ����ʱ��
    u16 TimeForAirOutEveryCycle;//ȼ�ϵ�ض�Ӧ����ʱ�䣨0-2000ms��
    u16 RatioOfAirBlower;//ռ�ձ�   ռ�ձ�ֻ�빦��ֵ�йأ���ǰ��������Ա�����޹أ�RW5��ռ�ձ��빦��Ҳ�޹أ�ֻ�Ǵ���RW4���ϵķ��ռ�ձ�
} AIR_PARAMETER_OF_POWERS_Typedef;

typedef struct {
    u16 AirOutCycle;
    u16 AirOutTimeInA_Cycle;
} AIR_OUT_PARAMETERS_Typedef;

//////////////////////////////////////////////////////////////////////////////////
//extern        u16                     IF_PARAMETERS_DEFAULT;  //size=1
//extern    REFORMINGROOM_TEMP_LINES    stREFORMINGROOM_TEMP_TABLE; //size=13
//extern    HYDRAULIC_PRESSURE_LINES    stHYDRAULIC_PRESSURE_TABLE;//size=4
//extern            SYSTEM_TEMPS        stSYSTEM_TEMP;             //size=3
//extern    BELOWER_ADJUST_PARAMETER    stHEATING_ADJUST_PARAMETER[3];//G-T,G 1-3        size=2*3
//extern    BELOWER_ADJUST_PARAMETER    stRUNNING_ADJUST_PARAMETER[2];//G-T,G 4��5       size=2*2
//extern    TIMES_FOR_IGNITIONCHECK     stSYSTEM_IGNITIONCHECK;                          //size=3

//extern        u16                     PUMP_PRESSURE_OUTPUT[12];//PUMP_PRESSURE_OUTPUT_NUM           //size=12

//extern        u16                     POWER[8];//8�ֹ���ֵ                                       size=8
//extern    AIR_PARAMETER_OF_POWERS     stPowerValue[8];    //��ͬ����ֵ��Ӧ����           size=3*8
//extern        u16                     CENTRIFUGAL_RATIO_IFABOVE_POWER8;//����>RW8                          size=1
//extern        u16                     CENTRIFUGAL_RATIO_IFABOVE_TEMP60; //�¶ȸ���60                       size=1

//extern        HEAT_AND_FLAME_TEMP     stHEAT_AND_FLAME_TEMP_TABLE;        //�¶�2��3 size=1*2


extern REFORMINGROOM_TEMP_LINES_Typedef stREFORMINGROOM_TEMP_TABLE; //size = 13
extern HYDRAULIC_PRESSURE_LINES_Typedef stHYDRAULIC_PRESSURE_TABLE; //size = 4
extern SYSTEM_TEMPS_Typedef stSYSTEM_TEMP;                              //size = 3
extern BELOWER_ADJUST_PARAMETER_Typedef stDIANHUOING_1_ADJUST_PARAMETER[3]; //G-T,G 1-3     size = 2*3
extern BELOWER_ADJUST_PARAMETER_Typedef stDIANHUOING_2_ADJUST_PARAMETER[2]; //G-T,G 4��5    size = 2*2
extern TIMES_FOR_IGNITIONCHECK_Typedef stSYSTEM_IGNITIONCHECK;          //size = 3
extern uint16_t PUMP_PRESSURE_OUTPUT[2];                                //size = 12

extern uint8_t g_u8PumpAdjLqdPrssTab;
extern uint8_t g_u8PumpRunSpdAfterAdj;
extern AIR_PARAMETER_OF_POWERS_Typedef stPowerValue[8];                 //8�ֹ���ֵ ����Ӧ������ʱ�����͵�ѷ��ռ�ձ� size = 4*8
extern uint16_t CENTRIFUGAL_RATIO_IFABOVE_POWER8;                       //size = 1
extern uint16_t CENTRIFUGAL_RATIO_IFABOVE_TEMP60;                       //size = 1
extern HEAT_AND_FLAME_TEMP_Typedef stHEAT_AND_FLAME_TEMP_TABLE;         //size = 3*1



#endif








