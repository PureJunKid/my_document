#ifndef __RUNNING_H
#define __RUNNING_H



void    Running(void);
void    SoftPowerOff(void);
//  PaiQi(uint16_t,uint16_t);
void    OFF_WaittingPaiZaFlag(void);
void    SetPileWorkingFlag(void);
SYSTEM_WHETHER_TYPE_VARIABLES_Typedef GetPileWorkingFlag(void);

#endif



