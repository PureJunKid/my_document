#include "include.h"
void LedAndBeepInit(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOF, ENABLE); //ʹ��GPIOA GPIOCʱ��

    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;//����ģʽ
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5;
    GPIO_Init(GPIOF, &GPIO_InitStructure);


}

/*********************************************
*   ���ܣ�����LED��
*   ������WhichLED ��������LEDȡֵ��ΧΪLED1 LED2 LED3 LED4
********************************************/
void LedOn(LED_NUM WhichLED)
{
    switch(WhichLED) {
        case LED1:
            GPIO_SetBits(GPIOF, GPIO_Pin_1);
            break;

        case LED2:
            GPIO_SetBits(GPIOF, GPIO_Pin_2);
            break;

        case LED3:
            GPIO_SetBits(GPIOF, GPIO_Pin_3);
            break;

        case LED4:
            GPIO_SetBits(GPIOF, GPIO_Pin_4);
            break;

        case LED5:
            GPIO_SetBits(GPIOF, GPIO_Pin_5);
            break;

        case LEDALL:
            GPIO_SetBits(GPIOF, GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5);
            break;

        default:
//      printf("--------------------->The LED parameter is error!\n");
    }
}
void LedOff(LED_NUM WhichLED)
{
    switch(WhichLED) {
        case LED1:
            GPIO_ResetBits(GPIOF, GPIO_Pin_1);
            break;

        case LED2:
            GPIO_ResetBits(GPIOF, GPIO_Pin_2);
            break;

        case LED3:
            GPIO_ResetBits(GPIOF, GPIO_Pin_3);
            break;

        case LED4:
            GPIO_ResetBits(GPIOF, GPIO_Pin_4);
            break;

        case LED5:
            GPIO_ResetBits(GPIOF, GPIO_Pin_5);
            break;

        case LEDALL:
            GPIO_ResetBits(GPIOF, GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5);
            break;

        default:
//      printf("--------------------->The LED parameter is error!\n");
    }
}

