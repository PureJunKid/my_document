#include "middleware.h"
#include "MX6675_read.h"

void PVD_Configuration(void);

void System_Configuration(void)
{
    /*ѡ���ⲿʱ�ӣ�����ϵͳʱ����72MHz*/
    RCC_Configuration();

    /*�����ж����ȷ�����ڲ��ж�����*/
    NVIC_Configuration();

    //CRC���㵥Ԫ����
//  CRC_Config();

    /*����SysTick��ʱ��*/
    SysTick_Configuration();

    /*����ϵͳʵʱʱ��*/
//  RTC_Configuration(); //Ŀǰ��ʱû��ʹ��

    USART_Configuration();
    /*CAN ����*/
    CAN_Configuration();

    /* �ڲ�ADC1���ò�����*/
    ADC_Configuration();
    //�趨MAX6675�ⲿģ��ת����
    ExtADC_Configuration();
    TEMP2_3_Select(TEMP3);
    /*��ģת������*/
    DAC_Configuration();

    /*---------------------USART_Init,TIM_Init------------*/

    TIMER_Configuration();

    /*�ⲿ�ж�����*/
    EXTI_Configuration();

    /*���籣������*/
    PVD_Configuration();
}

void USART_Configuration(void)
{
    USART1_Init();
//  USART2_Init();
//  USART3_Init();
    UART4_Init();
    UART5_Init();
}

void RTC_Configuration(void)
{
//  RTC_Init();
}

void SysTick_Configuration(void)
{
//  SysTick_Init();
    Systick_IdelayInit(72000000);
}

void NVIC_Configuration(void)
{
    USER_NVIC_Configuration();
}



void CAN_Configuration(void)
{
    CAN_GPIO_Init();
    CAN_NVIC_Init();
    CAN_Mode_Init();
    CAN_Filter_Init();
    CAN_SetMsg();
}

void ADC_Configuration()
{
    ADC_DMA_Configuration();
//  ADC_GPIO_Init();
//  ADC_BaseInit();
//  ADC_DMA_NVIC_Init();
//  ADC_DMA_Init();
//  ADC_StartAndCalibration();
}

void DAC_Configuration()
{
    DAC_GPIO_Init();
    DAC_BaseInit();
}

void TIMER_Configuration()
{
    TIM1_Init();
    TIM2_Init();
//  TIM3_Init();
    TIM4_Init();
    TIM5_Init();
    TIM6_Init();
    TIM7_Init();

}

void EXTI_Configuration()
{
    USER_EXTI_Init();
}

void UpMachineLED_StatuRefresh(DATA_REFRESH_FLAG_Typedef m_DATA_REFRESH_FLAG)
{
    if(m_DATA_REFRESH_FLAG == GROUP_ONE) {
        //������ָʾ��
        if(1 == GetHeaterStatu()) {
            CAN_MsgRefresh(CAN_TXMSG1, CANTXMSG1_HEATER_LED, RED);
        } else {
            CAN_MsgRefresh(CAN_TXMSG1, CANTXMSG1_HEATER_LED, BLUE);
        }

        //����ָʾ��
        if(GetRunningStatus() == RUNNING || (PRERUNNING_DIAN_HUO_ONE == GetRunningStatus()) || (PRERUNNING_DIAN_HUO_TWO == GetRunningStatus())) {
            CAN_MsgRefresh(CAN_TXMSG1, CANTXMSG1_RUN_LED, GREEN);
        } else {
            CAN_MsgRefresh(CAN_TXMSG1, CANTXMSG1_RUN_LED, BLUE);
        }

        //����ָʾ��
        if(1 == GetIgniterStatu()) {
            CAN_MsgRefresh(CAN_TXMSG1, CANTXMSG1_IGNITER_LED, GREEN);
        } else {
            CAN_MsgRefresh(CAN_TXMSG1, CANTXMSG1_IGNITER_LED, BLUE);
        }

        //�������ָʾ��
        if(0 != GetHydrgFanCtrlSpd()) {
            CAN_MsgRefresh(CAN_TXMSG1, CANTXMSG1_BLOWER_LED, GREEN);
        } else {
            CAN_MsgRefresh(CAN_TXMSG1, CANTXMSG1_BLOWER_LED, BLUE);
        }

        //Һλָʾ��
        if(GetAlarmStatu(WATER_LOW_ALARM) == ON) {
            CAN_MsgRefresh(CAN_TXMSG1, CANTXMSG1_WATER_LED, GREEN);
        } else {
            CAN_MsgRefresh(CAN_TXMSG1, CANTXMSG1_WATER_LED, BLUE);
        }
    } else if(m_DATA_REFRESH_FLAG == GROUP_TWO) {
        //����ѹ����
        if(GetAlarmStatu(AIR_PRESS_LOW_ALARM) == ON) {
            CAN_MsgRefresh(CAN_TXMSG2, CANTXMSG2_LOW_AIR_PRESS_ALARM_LED, GREEN);
        } else {
            CAN_MsgRefresh(CAN_TXMSG2, CANTXMSG2_LOW_AIR_PRESS_ALARM_LED, BLUE);
        }

        //����ѹ����
        if(GetAlarmStatu(AIR_PRESS_HIGH_ALARM) == ON) {
            CAN_MsgRefresh(CAN_TXMSG2, CANTXMSG2_HIGH_AIR_PRESS_ALARM_LED, GREEN);
        } else {
            CAN_MsgRefresh(CAN_TXMSG2, CANTXMSG2_HIGH_AIR_PRESS_ALARM_LED, BLUE);
        }

        //��Ѹ��¾���
        if(GetAlarmStatu(PILE_TEMP_HIGH_ALARM) == ON) {
            CAN_MsgRefresh(CAN_TXMSG2, CANTXMSG2_HIGH_PILE_TEMP_ALARM_LED, GREEN);
        } else {
            CAN_MsgRefresh(CAN_TXMSG2, CANTXMSG2_HIGH_PILE_TEMP_ALARM_LED, BLUE);
        }

        //��ѵ͵�ѹ����
        if(GetAlarmStatu(PILE_VOLT_LOW_ALARM) == ON) {
            CAN_MsgRefresh(CAN_TXMSG2, CANTXMSG2_LOW_VOLTAGE_ALARM_LED, GREEN);
        } else {
            CAN_MsgRefresh(CAN_TXMSG2, CANTXMSG2_LOW_VOLTAGE_ALARM_LED, BLUE);
        }
    }
}



