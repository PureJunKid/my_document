#include "mx6675_read.h"

#define MX6675_Bits_NUM  16
#define AVE_NUM     5


float ExtADC_Values[3][AVE_NUM] = {0};
uint8_t u8ReadCounter = 0;
float ExtADC_ValueSum[3] = {0};

float ExtADCConvertedValue[3] = {20, 20, 20};

uint8_t TEMP2_3_SELECT_VALUE;

uint8_t TEMP_READ_VALUE_FLAG = 0;
float   TEMP_VALUE_AVE[2] = {0};


//MX6675����
void ExtADC_Configuration()
{
    GPIO_InitTypeDef GPIO_InitStructure;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA
                           | RCC_APB2Periph_GPIOB
//                          | RCC_APB2Periph_GPIOC
//                          | RCC_APB2Periph_GPIOD
                           , ENABLE);//ʹ�����GPIO�ڵ�ʱ��

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);
    GPIO_PinRemapConfig(GPIO_Remap_SWJ_Disable, ENABLE);

    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;

    /******����GPIOB������*********/
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3 | GPIO_Pin_6;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4 | GPIO_Pin_5;// | GPIO_Pin_9;  //MX6675��ѡͨ���ź��ȵ�ż������2��3��ѡ�񿪹�
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    GPIO_ResetBits(GPIOB, GPIO_Pin_5); //���ֶ�MAX6675��ģ��ʱ�Ӵ��ڵ͵�ƽ״̬
    GPIO_SetBits(GPIOB, GPIO_Pin_4); //���ֶ�MAX6675��ѡͨ���Ŵ��ڸߵ�ƽ״̬
}

void TEMP2_3_Select(uint8_t TEMPx)
{
    /*
        if( TEMPx == TEMP2)
        {
            GPIO_SetBits(GPIOA,GPIO_Pin_8);//����PA8��ѡͨ�¶�2
        }
        else
        {
            GPIO_ResetBits(GPIOA,GPIO_Pin_8);//����PA8��ѡͨ�¶�3
        }
    */
    GPIO_ResetBits(GPIOB, GPIO_Pin_4); //����MX6675��Ƭѡ�źţ��Ա���������ת��
    TEMP2_3_SELECT_VALUE = (uint8_t) TEMPx;
}

void ReStartExtADC()
{
    CS1NO;  //�ͷ�Ƭѡ����ʼ��һ�ε�ת��������¼��ǰʱ��
}
/*
void SoftRead_MAX6675()
{
    if(GetRunningStatus() != WAITTINGCOMMAND)
    {
        if(ExtADCConvertedValue[0] >= 400)
        {
            ExtADCConvertedValue[0] = 400;
        }
        else
        {
            ExtADCConvertedValue[0] += 0.03;
        }
        if(ExtADCConvertedValue[2] >= 400)
        {
            ExtADCConvertedValue[2] = 400;
        }
        else
        {
            ExtADCConvertedValue[2] += 0.1;
        }
    }
}
*/

void SoftRead_MAX6675()
{
    uint16_t m_temp[2] = {0, 0};
    int i, j;

    CS1YES;

    for(i = 0; i < 9; i++);     //����Ƭѡѡ�к������MX6675��ʱ����Ҫ�ͺ�100ns������1us�������ڴ˿���ʱ8�Σ�ʱ������Ϊ13.8*8=111ns

    for(j = 0; j < MX6675_Bits_NUM; j++) {
        SCKUP;

        for(i = 0; i < 4; i++);//��MAX6675ʱ�Ӹߵ�ƽά��ʱ�䲻�ö���100ns�������ڶ�ȡ����ǰ�������ʱ4�Σ���֤����׼ȷ��

        m_temp[0] = (m_temp[0] << 1) | SO1;
        m_temp[1] = (m_temp[1] << 1) | SO23;

        for(i = 0; i < 4; i++);

        SCKDOWN;

        for(i = 0; i < 9; i++);//����һbitʱ��Ҫ��100ns���ϵĵ͵�ƽ����ʱ��
    }

    CS1NO;

    if((m_temp[0] & (1 << 15 | 4)) == 0) { //������ȷ���ȵ�ż��δ����
        m_temp[0] &= 0x7FFF;
        m_temp[0] >>= 3;
    } else {
        m_temp[0] = 0xF9C;
    }

    if((m_temp[1] & (1 << 15 | 4)) == 0) { //������ȷ���ȵ�ż��δ����
        m_temp[1] &= 0x7FFF;
        m_temp[1] >>= 3;
    } else {
        m_temp[1] = 0xF9C;
    }

    if(TEMP_READ_VALUE_FLAG < 4) {
        if(TEMP_READ_VALUE_FLAG == 0) {
            TEMP_VALUE_AVE[0] = 0.0;
            TEMP_VALUE_AVE[1] = 0.0;
        }

        TEMP_VALUE_AVE[0] += (float)m_temp[0] / 4.0;
        TEMP_VALUE_AVE[1] += (float)m_temp[1] / 4.0;
        TEMP_READ_VALUE_FLAG ++;
    } else {
        TEMP_READ_VALUE_FLAG = 0;

        if(u8ReadCounter < AVE_NUM) {
            ExtADC_Values[0][u8ReadCounter] = TEMP_VALUE_AVE[0] / REFORMROOM_TEMP_TO_MAX6675LSB_RATIO;
            ExtADC_ValueSum[0] += ExtADC_Values[0][u8ReadCounter];
            ExtADCConvertedValue[0] = ((float) ExtADC_ValueSum[0]) / (u8ReadCounter + 1);

            ExtADC_Values[TEMP2_3_SELECT_VALUE][u8ReadCounter] = TEMP_VALUE_AVE[1] / REFORMROOM_TEMP_TO_MAX6675LSB_RATIO;
            ExtADC_ValueSum[TEMP2_3_SELECT_VALUE] += ExtADC_Values[TEMP2_3_SELECT_VALUE][u8ReadCounter];
            ExtADCConvertedValue[TEMP2_3_SELECT_VALUE] = ((float) ExtADC_ValueSum[TEMP2_3_SELECT_VALUE]) / (u8ReadCounter + 1);
        } else {
            if(u8ReadCounter >= AVE_NUM * 2) {
                u8ReadCounter = AVE_NUM;
            }

            ExtADC_ValueSum[0] -= ExtADC_Values[0][u8ReadCounter % AVE_NUM];
            ExtADC_Values[0][u8ReadCounter % AVE_NUM] =  TEMP_VALUE_AVE[0] / REFORMROOM_TEMP_TO_MAX6675LSB_RATIO;
            ExtADC_ValueSum[0] += ExtADC_Values[0][u8ReadCounter % AVE_NUM];
//          printf("ExtADC_Value0 %f<---\r\n", ExtADC_Values[0][u8ReadCounter % AVE_NUM]);
            ExtADCConvertedValue[0] = ((float) ExtADC_ValueSum[0]) / AVE_NUM;

            ExtADC_ValueSum[TEMP2_3_SELECT_VALUE] -= ExtADC_Values[TEMP2_3_SELECT_VALUE][u8ReadCounter % AVE_NUM];
            ExtADC_Values[TEMP2_3_SELECT_VALUE][u8ReadCounter % AVE_NUM] = TEMP_VALUE_AVE[1] / REFORMROOM_TEMP_TO_MAX6675LSB_RATIO;
            ExtADC_ValueSum[TEMP2_3_SELECT_VALUE] += ExtADC_Values[TEMP2_3_SELECT_VALUE][u8ReadCounter % AVE_NUM];
//          printf("TEMP2_3_Select is %d, ExtADC_Value2 %f<---\r\n", TEMP2_3_SELECT_VALUE, ExtADC_Values[0][u8ReadCounter % AVE_NUM]);
            ExtADCConvertedValue[TEMP2_3_SELECT_VALUE] = ((float) ExtADC_ValueSum[TEMP2_3_SELECT_VALUE]) / AVE_NUM;
        }

        u8ReadCounter ++;
    }

}


float GetRefromRoomTemp(void)
{
    return ExtADCConvertedValue[2];
}

float GetRodTemp(void)
{
    if(TEMP2_3_SELECT_VALUE == TEMP2) {
        return ExtADCConvertedValue[1];
    } else {
        return 0xF9C;
    }
}

float GetFireTemp(void)
{
    if(TEMP2_3_SELECT_VALUE == TEMP3) {
        return ExtADCConvertedValue[0];
    } else {
        return 0xF9C;
    }
}
