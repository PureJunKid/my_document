#ifndef __DELAY_H
#define __DELAY_H

#include "stm32f10x.h"
#include "stm32f10x_conf.h"
#include "system_stm32f10x.h"
#include "systemstatuparameters.h"

typedef enum {
    Delay_SUCCESS = 0,
    Delay_BREAK
} DELAY_STATU;

//void Delay_ms(u16 nms);
DELAY_STATU Delay_s(uint32_t ns, SYSTEM_RUNNING_STATUS_Typedef m_enSYSTEM_RUNNING_STATU);
#endif

















