#ifndef _SIGNALNAMEConfig_H_
#define _SIGNALNAMEConfig_H_
#include "stm32f10x.h"


//output config
#define     Output48VSwitchON       GPIO_SetBits(GPIOC,GPIO_Pin_3)//48V���ֱ���Ӵ�����
#define     Output48VSwitchOFF      GPIO_ResetBits(GPIOC,GPIO_Pin_3)//�ر�

//#define       H2_MakeBlower_ON        GPIO_SetBits(GPIOB,GPIO_Pin_7)//�����������
//#define       H2_MakeBlower_OFF       GPIO_ResetBits(GPIOB,GPIO_Pin_7)

#define     BeepON                  GPIO_SetBits(GPIOC,GPIO_Pin_13)//������
#define     BeepOFF                 GPIO_ResetBits(GPIOC,GPIO_Pin_13)

#define     LED3_ON                 GPIO_SetBits(GPIOB,GPIO_Pin_10)//���LED��
#define     LED3_OFF                GPIO_ResetBits(GPIOB,GPIO_Pin_10)

#define     ExtLED_ON               GPIO_SetBits(GPIOB,GPIO_Pin_12)//���LED
#define     ExtLED_OFF              GPIO_ResetBits(GPIOB,GPIO_Pin_12)
#define     ExtLED_Exchange         (GPIO_ReadOutputDataBit(GPIOB,GPIO_Pin_12)? GPIO_ResetBits(GPIOB,GPIO_Pin_12):GPIO_SetBits(GPIOB,GPIO_Pin_12))


#define     AirInON                 GPIO_SetBits(GPIOC,GPIO_Pin_1)//������ŷ�
#define     AirInOFF                GPIO_ResetBits(GPIOC,GPIO_Pin_1)

#define     AirExON                 GPIO_SetBits(GPIOC,GPIO_Pin_2)  //������ŷ�
#define     AirExOFF                GPIO_ResetBits(GPIOC,GPIO_Pin_2)

#define     HeaterON                GPIO_SetBits(GPIOB,GPIO_Pin_9)//������������
#define     HeaterOFF               GPIO_ResetBits(GPIOB,GPIO_Pin_9)
#define     GetHeaterStatu()        GPIO_ReadOutputDataBit(GPIOB,GPIO_Pin_9)

#define     IgniterON               GPIO_SetBits(GPIOB,GPIO_Pin_8)//�����
#define     IgniterOFF              GPIO_ResetBits(GPIOB,GPIO_Pin_8)
#define     GetIgniterStatu()       GPIO_ReadOutputDataBit(GPIOB,GPIO_Pin_8)

#define     MagneticValve1ON        GPIO_SetBits(GPIOA,GPIO_Pin_15)//��ŷ�1
#define     MagneticValve1OFF       GPIO_ResetBits(GPIOA,GPIO_Pin_15)

#define     MagneticValve2ON        GPIO_SetBits(GPIOA,GPIO_Pin_14)//��ŷ�2
#define     MagneticValve2OFF       GPIO_ResetBits(GPIOA,GPIO_Pin_14)

#define     PileBlowerSwitchON          GPIO_SetBits(GPIOC,GPIO_Pin_14)   //��ѹķ������
#define     PileBlowerSwitchOFF         GPIO_ResetBits(GPIOC,GPIO_Pin_14)

#define     PumpSwitchON            GPIO_SetBits(GPIOA, GPIO_Pin_13)     //ˮ�ÿ���
#define     PumpSwitchOFF           GPIO_ResetBits(GPIOA, GPIO_Pin_13)

#define     ReformRoomKeepWarmON    GPIO_SetBits(GPIOC, GPIO_Pin_15)
#define     ReformRoomKeepWarmOFF           GPIO_ResetBits(GPIOC, GPIO_Pin_15)

#define     H2MakerBlowerPowerSwitchON          GPIO_SetBits(GPIOA, GPIO_Pin_5)
#define     H2MakerBlowerPowerSwitchOFF         GPIO_ResetBits(GPIOA, GPIO_Pin_5)

#define     BrownoutProtectSwitchON         GPIO_SetBits(GPIOB, GPIO_Pin_2)
#define     BrownoutProtectSwitchOFF        GPIO_SetBits(GPIOB, GPIO_Pin_2)

//#define       KeepElectricMakerWarmON     GPIO_SetBits(GPIOE,GPIO_Pin_5)  //��Ѽ���
//#define       KeepElectricMakerWarmOFF    GPIO_SetBits(GPIOE,GPIO_Pin_5)

#if 0
    #define     ExtLED_ON               1
    #define     ExtLED_OFF              1
    #define     ExtLED_Exchange         2
#endif

void SetAirBlowerSpeed(void);

#endif
