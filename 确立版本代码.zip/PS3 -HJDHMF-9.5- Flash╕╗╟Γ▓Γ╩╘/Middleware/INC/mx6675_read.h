#ifndef _MX6675_SPI_H_
#define _MX6675_SPI_H_

#include "stdio.h"
#include "stm32f10x.h"
#include "stm32f10x_conf.h"
#include "middleware.h"
#include "systemstatuparameters.h"

#define TEMP2 ((uint8_t) 1)
#define TEMP3 ((uint8_t) 2)

#define REFORMROOM_TEMP_TO_MAX6675LSB_RATIO   4.0 //MAX6675��LSB���¶ȵı�������

#define MX6675_CONVER_TIME 250   //�б�Ҫʱ�������Ϊ220

#define     CS1YES                  GPIO_ResetBits(GPIOB,GPIO_Pin_4);//cs1
#define     CS1NO                   GPIO_SetBits(GPIOB,GPIO_Pin_4);

#define     SCKUP                   GPIO_SetBits(GPIOB,GPIO_Pin_5);//sck
#define     SCKDOWN                 GPIO_ResetBits(GPIOB,GPIO_Pin_5);

#define     SO1                     GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_6)//��ȡSO1
#define     SO23                    GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_3);//��ȡSO23

void ExtADC_Configuration(void);

void TEMP2_3_Select(uint8_t TEMPx);

void SoftRead_MAX6675(void);
void ReStartExtADC(void);


float GetRefromRoomTemp(void);
float GetFireTemp(void);
float GetRodTemp(void);


#endif


