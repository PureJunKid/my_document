#ifndef __INCLUDE_H
#define __INCLUDE_H

#include "stdio.h"
#include "stm32f10x.h"
#include "stm32f10x_conf.h"
#include "system_stm32f10x.h"

#include "outputcontrol.h"

#include "pvd.h"
#include "rcc.h"
#include "led.h"
#include "gpio.h"
#include "nvic.h"
#include "adc.h"
#include "dac.h"
#include "timer.h"
#include "can.h"
#include "usart.h"
#include "delay.h"
#include "screen.h"

#include "mx6675_read.h"
#include "stmflash.h"
#include "parameters.h"
#include "running.h"
#include "sdcard.h"
#include "systick.h"
#include "prestart.h"
#include "systemstatuparameters.h"



/*

SYSTEM_RUNNING_STATUS_TYPE ReadRunningStatuFlag(void);
H2_MAKE_TIME_TPYEdef GetH2_MakeTime(void);
void CheckINLevel(void);
void SoftPowerOff(void);
void PaiQi(void);
*/


#endif
