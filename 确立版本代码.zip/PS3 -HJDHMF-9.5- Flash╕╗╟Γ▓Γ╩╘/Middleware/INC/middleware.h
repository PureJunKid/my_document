#ifndef __MIDDLEWARE_H
#define __MIDDLEWARE_H

#include "stm32f10x.h"
#include "stm32f10x_conf.h"
#include "system_stm32f10x.h"
#include "outputcontrol.h"
#include "adc.h"
#include "can.h"
#include "crc.h"
#include "dac.h"
#include "dma.h"
#include "exti.h"
#include "gpio.h"
#include "nvic.h"
#include "rcc.h"
#include "rtc.h"
#include "systick.h"
#include "timer.h"
#include "usart.h"

void System_Configuration(void);
void USART_Configuration(void);
void RTC_Configuration(void);
void SysTick_Configuration(void);
void NVIC_Configuration(void);
void CAN_Configuration(void);
void ADC_Configuration(void);
void DAC_Configuration(void);
void USART_Configuration(void);
void TIMER_Configuration(void);
void EXTI_Configuration(void);
void ExtKeyInterruptDisable(void);
void ExtKeyInterruptEnable(void);

void UpMachineLED_Refresh(void);

void SoftPowerOff(void);
void KeepingWarm(void);




#endif


