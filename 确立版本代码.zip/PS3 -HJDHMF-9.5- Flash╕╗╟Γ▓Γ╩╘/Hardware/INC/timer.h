#ifndef _TIMER_H_
#define _TIMER_H_

typedef enum {
    BEEP_DELAY_100MS_OFF = 0,
//    ADJUST_VI_BY_HW_10S,
    BLOWER_DELAY_5S_OFF,
//  Igniter_DELAY_120S_OFF,
    Decompression_Time_Update_1S,
    ELECTRIC_OFF_DELAY_5000,
    PAI_ZA_FOR_5000,
    UP_MACHINE_BEEP_ANSWER_DELAY_500,
    FOR_EXT_SWITCH_CHECK_DELAY_500,
    SOFT_POWER_OFF_DELAY_10S_AirValveOFF,
    SOFT_POWER_OFF_DELAY_2S_BLOWER_OFF_TIME_CHECK,
    SOFT_POWER_OFF_LED_AND_BEEP_ANSWER,
    ExtLED_FLASH,

    TASK_MAX_NUM
} TIM6_TASK_KIND_Typedef;
typedef struct {
    TIM6_TASK_KIND_Typedef Task;
    uint16_t WaittingTime;
} TIM6_WAITTING_TASK_KIND_AND_DELAY_TIME_Typedef;

typedef enum {
    DATA_SEND_GROUP_ONE = 0,
    DATA_SEND_GROUP_TWO,
    DATA_SEND_GROUP_THREE,
} DATA_SEND_FLAG_Typedef;

typedef enum {
    GROUP_ONE = 0,
    GROUP_TWO = !GROUP_ONE
} DATA_REFRESH_FLAG_Typedef;



typedef enum {
    TEMP_HIGH_POWER_OFF_BLOWER_DELAY_5S = 0,

} TIM7_TASK_FLAG;

void TIM1_Init(void);

void TIM2_Init(void);
void TIM2_GPIO_Init(void);
void TIM2_BaseInit(void);
void TIM2_OC_Init(void);
void TIM2_NVIC_Init(void);


void TIM3_Init(void);
void TIM3_GPIO_Init(void);
void TIM3_BaseInit(void);
void TIM3_OC_Init(void);
void TIM3_NVIC_Init(void);

void TIM2_ForIgniteStart(void);
void SetPaiQiParametersFromCurrentPower(void);
void SetPaiQiParameters(uint16_t, uint16_t);
void StopRunningPaiQi(void);

void TIM2_PaiQiStart(void);
//void TIM2_PaiQiStart(float, float);

void TIM4_Init(void);
void TIM4_GPIO_Init(void);
void TIM4_BaseInit(void);
void TIM4_OC_Init(void);
void TIM4_NVIC_Init(void);
void SetTIM4_Channel2PWM_Ratio(uint8_t);

void SetTxMsgRefreshGroup(DATA_REFRESH_FLAG_Typedef m_NEW_GROUT_FLAG);

void TIM5_Init(void);
void TIM5_GPIO_Init(void);
void TIM5_BaseInit(void);
void TIM5_OC_Init(void);
void TIM5_NVIC_Init(void);

void TIM6_Init(void);
void UpMachineBeepAnswer(void);
void ForExtSwitchCheckStart(void);
void ExtLED_FlashForKeepingWarm(void);
void Delay3MinStopHydrgFan(void);
void StartTIM6(TIM6_TASK_KIND_Typedef m_TIM6taskflag, u16 ARR);
void AddTIM6NewTaskInTIM6_IRQ(TIM6_TASK_KIND_Typedef m_TIM6taskflag, u16 ARR);

void AnswerDelayTask(TIM6_TASK_KIND_Typedef m_NEW_TASK);

void TIM7_Init(void);

void TIM8_Init(void);
void TIM8_GPIO_Init(void);
void TIM8_BaseInit(void);
void TIM8_OC_Init(void);
void TIM8_NVIC_Init(void);


void TIM9_Init(void);
void TIM9_GPIO_Init(void);
void TIM9_BaseInit(void);
void TIM9_OC_Init(void);
void TIM9_NVIC_Init(void);


void TIM10_Init(void);
void TIM10_GPIO_Init(void);
void TIM10_BaseInit(void);
void TIM10_OC_Init(void);
void TIM10_NVIC_Init(void);

void StartTIM10(uint8_t);

void TIM11_Init(void);
void TIM11_GPIO_Init(void);
void TIM11_BaseInit(void);
void TIM11_OC_Init(void);
void TIM11_NVIC_Init(void);

void StartTIM11(uint8_t);

void TIM12_Init(void);
void TIM12_GPIO_Init(void);
void TIM12_BaseInit(void);
void TIM12_OC_Init(void);
void TIM12_NVIC_Init(void);

void TIM13_Init(void);
void TIM13_GPIO_Init(void);
void TIM13_BaseInit(void);
void TIM13_OC_Init(void);
void TIM13_NVIC_Init(void);

void TIM14_Init(void);
void TIM14_GPIO_Init(void);
void TIM14_BaseInit(void);
void TIM14_OC_Init(void);
void TIM14_NVIC_Init(void);


void SetHydrgFanSpd(uint8_t);

void StopHydrgFan(void);

void HydrgFanSpdInc(void);
void HydrgFanSpdDec(void);
uint8_t GetHydrgFanCtrlSpd(void);

uint8_t GetDecompressCountPerMinute(void);
void PassiveDecompressCurrentNmbInc(void);
#endif
