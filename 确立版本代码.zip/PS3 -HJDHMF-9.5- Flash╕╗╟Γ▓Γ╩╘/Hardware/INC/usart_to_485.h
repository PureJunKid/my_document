#ifndef _USART_TO_485_H_
#define _USART_TO_485_H_

#include "stm32f10x.h"

void USART5SendCmd(char *CmdBuf);
void HWDC_Autho_SetVIvalue(uint16_t Vvalue, uint16_t Ivalue );




#endif
