#ifndef __CRC_H
    #define __CRC_H
    #include "stm32f10x.h"

    void CRC_Config(void);

    u16 GetCRC16(const u8 *pmsg, u8 len);

#endif

