#ifndef __CTRL_KEY_H
#define __CTRL_KEY_H

//
//#define KEY0 PEin(4)      //PE4
//#define KEY1 PEin(3)  //PE3
//#define KEY2 PEin(2)  //PE2
//#define KEY3 PAin(0)  //PA0  WK_UP

#define AC220_MONITOR  GPIO_ReadInputDataBit(GPIOG,GPIO_Pin_0)//��ȡAC220_MONITOR
#define POWER_ON  GPIO_ReadInputDataBit(GPIOG,GPIO_Pin_1)//��ȡPOWER_ON
#define STOP_MONITOR  GPIO_ReadInputDataBit(GPIOG,GPIO_Pin_3)//��ȡSTOP_MONITOR 
#define WORK_MODE  GPIO_ReadInputDataBit(GPIOG,GPIO_Pin_4)//��ȡWORK_MODE
#define IN2  GPIO_ReadInputDataBit(GPIOG,GPIO_Pin_5)//��ȡIN2
#define IN1  GPIO_ReadInputDataBit(GPIOG,GPIO_Pin_10)//��ȡIN1

#define GetPassiveGpioStatu  GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_15)


/*
#define KEY_UP      4
#define KEY_LEFT    3
#define KEY_DOWN    2
#define KEY_RIGHT   1

*/

void USER_EXTI_Init(void);
void EXTI_NVIC_Init(void);
#endif
