#ifndef _PVD_H_
    #define _PVD_H_

    #include "systemstatuparameters.h"


    void PVD_ProtectStatuCmd(SYSTEM_SWITCH_VARIABLES_STATU_Typedef);



#endif

