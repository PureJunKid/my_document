#ifndef _RCC_H_
    #define _RCC_H_

    void RCC_Configuration(void);

#endif



