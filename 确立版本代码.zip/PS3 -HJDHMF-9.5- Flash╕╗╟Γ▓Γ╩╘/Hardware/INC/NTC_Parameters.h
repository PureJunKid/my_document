#ifndef _NTC_RESISTANCE_H_
#define _NTC_RESISTANCE_H_

#include "stdint.h"

typedef struct {
    uint8_t temp;
    uint32_t resistance;
} NTC_PARAMETER_TABLE_Typedef;


uint8_t GetSourceTemp(double Rt_Value);














#endif



