#ifndef __SCREEN_H
    #define __SCREEN_H

    void ScreenInit(void);

    void UpdateScreen(void);












#endif

