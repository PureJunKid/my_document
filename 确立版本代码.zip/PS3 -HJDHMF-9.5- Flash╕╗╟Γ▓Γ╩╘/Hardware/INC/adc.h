#ifndef _ADC_H_
#define _ADC_H_

typedef enum {
    ADC_SENSOR_CALIBRATED_NOT_YET,
    ADC_SENSOR_CALIBRATED_ALREADY,
} ADC_SENSOR_CALIBRATING_Typedef;

typedef enum {
    PILE_TEMP = 0,
    PILE_VOLT,
    PILE_CURRENT,

    LIQUID_PRESS,
    AIR_PRESS_1,
    AIR_PRESS_2,

    RESERVED_1,
    RESERVED_2,
    RESERVED_3
} ANA_INPUT_NUM_Typedef;

void ADC_DMA_Configuration(void);
void ADC_GPIO_Init(void);
void ADC_BaseInit(void);
void ADC_DMA_Init(void);
void ADC_DMA_NVIC_Init(void);
void ADC_StartAndCalibration(void);



double GetSourceANA_Value(ANA_INPUT_NUM_Typedef m_ANA_Input_Kind);
double GetCurrentPower(void);


void YeWeiCheck(void);
void VoltCheck(void);





#endif
