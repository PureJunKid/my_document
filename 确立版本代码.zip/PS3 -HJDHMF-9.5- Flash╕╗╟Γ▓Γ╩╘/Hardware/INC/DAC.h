#ifndef _DAC_H_
#define _DAC_H_

void DAC_GPIO_Init(void);
void DAC_BaseInit(void);

void DAC1SetVol(u16 vol);
void DAC2SetVol(u16 vol);
void SetHydrgPumpSpd(u8 vol);
void PumpSpeedDec(void);
void PumpSpeedInc(void);
void PumpStop(void);
uint8_t GetPumpSpeed(void);

void SetStackFanSpd(u8 vol);
u8 GetStackFansSpeed(void);
void StackFanSpdInc(void);
void StackFanSpdDec(void);
void PileBlowerStop(void);
uint8_t GetStackFanSpd(void);

#endif
