#ifndef __USART_H
#define __USART_H



void USART_Configuration(void);

void USART1_Init(void);
void USART1_GPIO_Init(void);
void USART1_BaseInit(void);
void USART1_NVIC_Init(void);
void USART1_DMA_Init(void);


void USART2_Init(void);
void USART2_GPIO_Init(void);
void USART2_BaseInit(void);
void USART2_NVIC_Init(void);
void USART2_DMA_Init(void);

void USART2_DMA_Configuration(void);
//void USART2_Send_CAN_Msg(u8*, u8);


void USART3_Init(void);
void USART3_GPIO_Init(void);
void USART3_BaseInit(void);
void USART3_NVIC_Init(void);
void USART3_DMA_Init(void);


void UART4_Init(void);
void UART4_GPIO_Init(void);
void UART4_BaseInit(void);
void UART4_NVIC_Init(void);
void UART4_DMA_Init(void);

void UART4_DMA_Configuration(void);
void UART4_Send_CAN_Msg(u8 *, u8);


void UART5_Init(void);
void UART5_GPIO_Init(void);
void UART5_BaseInit(void);
void UART5_NVIC_Init(void);
void UART5_DMA_Init(void);

#endif
