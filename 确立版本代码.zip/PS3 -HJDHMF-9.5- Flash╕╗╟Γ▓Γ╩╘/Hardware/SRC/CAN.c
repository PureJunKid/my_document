#include "include.h"
#include "stm32f10x.h"
#include "stm32f10x_conf.h"
#include "system_stm32f10x.h"
#include "can.h"
#ifdef HMRIH008
u8 TxMessage[4][TxPKG_SIZE] = {0};               //���ͻ�����
#endif
#ifdef HMF009_1
u8 TxMessage[2][TxPKG_SIZE] = {0};
#endif
u8 RxMessage[RxPKG_SIZE] = {0};                     //���ջ�����


u8 CanRxBuf[RxPKG_SIZE] = {0};
u8 bufPointer = 0;
u8 bufStatus = 0;


void CAN_GPIO_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;

    //����ʱ������
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO | RCC_APB2Periph_GPIOD, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_CAN1, ENABLE);

    /*      //��Ӧ��ӳ������ö�
    //  GPIO_PinRemapConfig(GPIO_Remap1_CAN1, ENABLE);
        // Configure CAN pin: RX                                                   // PD1
        GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;                // ��������
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
        GPIO_Init(GPIOD, &GPIO_InitStructure);
        // Configure CAN pin: TX                                                   // PD1
        GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;              // �����������
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
        GPIO_Init(GPIOD, &GPIO_InitStructure);
    */
    //��Ӧδ��ӳ������ö�

    // Configure CAN pin: RX                                                   // PA11
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;                // ��������
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    // Configure CAN pin: TX                                                   // PA12
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;              // �����������
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

}

void CAN_NVIC_Init(void)
{
    NVIC_InitTypeDef NVIC_InitStructure;

    NVIC_InitStructure.NVIC_IRQChannel = CAN1_RX0_IRQn;// USB_LP_      //CAN1 RX0�ж�
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;          //��ռ���ȼ�0
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;             //�����ȼ�Ϊ0
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}

void CAN_Mode_Init(void)
{
    CAN_InitTypeDef        CAN_InitStructure;
    /************************CANͨ�Ų�������**********************************/
    /*CAN�Ĵ�����ʼ��*/
    CAN_DeInit(CAN1);
    CAN_StructInit(&CAN_InitStructure);
    /*CAN��Ԫ��ʼ��*/
    CAN_InitStructure.CAN_TTCM = DISABLE;              //MCR-TTCM  �ر�ʱ�䴥��ͨ��ģʽʹ��
    CAN_InitStructure.CAN_ABOM = ENABLE;               //MCR-ABOM  �Զ����߹���
    CAN_InitStructure.CAN_AWUM = ENABLE;               //MCR-AWUM  ʹ���Զ�����ģʽ
    CAN_InitStructure.CAN_NART = DISABLE;              //MCR-NART  ��ֹ�����Զ��ش�   DISABLE-�Զ��ش�
    CAN_InitStructure.CAN_RFLM = DISABLE;              //MCR-RFLM  ����FIFO ����ģʽ  DISABLE-���ʱ�±��ĻḲ��ԭ�б���
    CAN_InitStructure.CAN_TXFP = DISABLE;              //MCR-TXFP  ����FIFO���ȼ� DISABLE-���ȼ�ȡ���ڱ��ı�ʾ��
    CAN_InitStructure.CAN_Mode = CAN_Mode_Normal;  //��������ģʽ
    CAN_InitStructure.CAN_SJW = CAN_SJW_1tq;           //BTR-SJW ����ͬ����Ծ���� 1��ʱ�䵥Ԫ
    CAN_InitStructure.CAN_BS1 = CAN_BS1_12tq;          //BTR-TS1 ʱ���1 ռ����12��ʱ�䵥Ԫ
    CAN_InitStructure.CAN_BS2 = CAN_BS2_3tq;           //BTR-TS1 ʱ���2 ռ����3��ʱ�䵥Ԫ
    CAN_InitStructure.CAN_Prescaler = 9;           ////BTR-BRP �����ʷ�Ƶ��  ������ʱ�䵥Ԫ��ʱ�䳤�� 36/(1+12+3)/9=0.25Mbps
    CAN_Init(CAN1, &CAN_InitStructure);
}


void CAN_Filter_Init(void)
{
    CAN_FilterInitTypeDef  CAN_FilterInitStructure;

    /*CAN��������ʼ��*/
    CAN_FilterInitStructure.CAN_FilterNumber = 0;                   //��������0
    CAN_FilterInitStructure.CAN_FilterMode = CAN_FilterMode_IdMask; //�����ڱ�ʶ������λģʽ
    CAN_FilterInitStructure.CAN_FilterScale = CAN_FilterScale_32bit; //������λ��Ϊ����32λ��
    /* ʹ�ܱ��ı�ʾ�����������ձ�ʾ�������ݽ��бȶԹ��ˣ���չID�������µľ����������ǵĻ��������FIFO0�� */

    CAN_FilterInitStructure.CAN_FilterIdHigh = (((u32)0x1314 << 3) & 0xFFFF0000) >> 16;         //Ҫ���˵�ID��λ
    CAN_FilterInitStructure.CAN_FilterIdLow = (((u32)0x1314 << 3) | CAN_ID_EXT | CAN_RTR_DATA) & 0xFFFF; //Ҫ���˵�ID��λ
    CAN_FilterInitStructure.CAN_FilterMaskIdHigh = 0xFFFF;          //��������16λÿλ����ƥ��
    CAN_FilterInitStructure.CAN_FilterMaskIdLow = 0xFFFF;           //��������16λÿλ����ƥ��
    CAN_FilterInitStructure.CAN_FilterFIFOAssignment = CAN_Filter_FIFO0 ;           //��������������FIFO0
    CAN_FilterInitStructure.CAN_FilterActivation = ENABLE;          //ʹ�ܹ�����
    CAN_FilterInit(&CAN_FilterInitStructure);
    /*CANͨ���ж�ʹ��*/
    CAN_ITConfig(CAN1, CAN_IT_FMP0, ENABLE);
}


void CAN_SetMsg(void)
{
#ifdef HMRH008
    TxMessage[0][0] = 0xF1;
    TxMessage[0][1] = 0x80;

    TxMessage[1][0] = 0xF2;
    TxMessage[1][1] = 0xC0;

    TxMessage[2][0] = 0xF3;
    TxMessage[2][1] = 0xE0;

    TxMessage[3][0] = 0xF4;
    TxMessage[3][1] = 0xE0;
#endif
#ifdef HMF009_1
    TxMessage[0][0] = 0xF7;
    TxMessage[0][1] = 0xF8;

    TxMessage[1][0] = 0xF1;
    TxMessage[1][1] = 0xF2;
#endif
}

void CAN_MsgRefresh(CAN_TXMSGx MSGx, CAN_TXMSGx_DATAx MSGx_DATAx, uint8_t VALUE)
{
#ifdef HMRIH008
    TxMessage[MSGx][MSGx_DATAx] = VALUE;
#endif

#ifdef HMF009_1
    TxMessage[MSGx][MSGx_DATAx] = VALUE;
#endif
}


void CAN_SendMsg(CAN_TXMSGx MSGx)
{
    u16 l_u16CRC_Value;
//  Can_Send_Long_Msg((TxMessage[MSGx]), PKG_SIZE, 12, CAN_DATA);
    l_u16CRC_Value = GetCRC16(TxMessage[MSGx], TxPKG_SIZE - 2);

    TxMessage[MSGx][TxPKG_SIZE - 2] = (uint8_t)((l_u16CRC_Value & 0xFF00) >> 8);
    TxMessage[MSGx][TxPKG_SIZE - 1] = (uint8_t)(l_u16CRC_Value & 0x00FF);

    UART4_Send_CAN_Msg((TxMessage[MSGx]), TxPKG_SIZE);
}


/*
 * Function Name: Can_Send_Long_Msg
 * Description  : Could send a CAN packet over 8 bytes
 * Parameter    : u8* msg   -- message to be sent
 *                u32 len   -- message length
 *                u32 StdId -- Standard ID
 *                u32 ExtId -- Extend ID
 * Returns      : below 0   -- failed
 *                other     -- number of sent package
 */
int Can_Send_Long_Msg(u8 *msg, u32 len, u8 addr, u8 func)
{
    u32 i;
    u32 j;
    u8  mbox;
    CanTxMsg TxMsg;
//  TxMsg.StdId = StdId;
//  TxMsg.ExtId = ExtId;
//  TxMsg.IDE = 0;
//  TxMsg.RTR = 0;
//  TxMsg.DLC = 1;
//  TxMsg.Data[0] = len;
//
//  mbox= CAN_Transmit(CAN1, &TxMsg);
//  j = 0;
//  while((CAN_TransmitStatus(CAN1, mbox)
//          == CAN_TxStatus_Failed) && (j < 0xfff))
//      j++;    //�ȴ����ͽ���
//  if(j >= 0xfff)
//      return -j;
//  j = 0xfff;
//  while(--j);
    TxMsg.IDE = CAN_ID_STD;
    TxMsg.RTR = CAN_RTR_DATA;

    for(i = 0; i < len / 8 + ((len % 8) ? 1 : 0); i++) {
        TxMsg.StdId = (((((u32)(addr)) << 3)) | ((u32)func));
//      printf("\n\rTxMsg.StdId = 0x%x\n\r", TxMsg.StdId);
//      TxMsg.ExtId = 0;

        TxMsg.DLC = ((len - i * 8) > 8) ? 8 : (len - i * 8);

//      TxMsg.Data[0] = i;
        for(j = 0; j < 8; j++) {
            TxMsg.Data[j] = msg[i * 8 + j];
        }

        mbox = CAN_Transmit(CAN1, &TxMsg);
        j = 0;

        while(CAN_TransmitStatus(CAN1, mbox) != CANTXOK) {}

        /*      while((CAN_TransmitStatus(CAN1, mbox)
                        == CAN_TxStatus_Failed) && (j < 0x1fff))
                    j++;
                if(j >= 0x1fff)
                {
                    bufPointer = 0;
                    bufStatus  = 1;
                    return -j;
                }
        */
    }

    return (len / 8 + ((len % 8) ? 1 : 0));
}

/*
 * Function Name: Can_Recv_Long_Msg
 * Description  : Could Receive a CAN packet over 8 bytes
 * Parameter    : u8* buf -- receive buffer
 */
void Can_Recv_Long_Msg(u8 *longbuf)
{
    /*
       u32 i;
    u8 j;
    u8 k;
    u32 len;

    CanRxMsg RxMsg;
    if(CAN_MessagePending(CAN1, CAN_FIFO0) == 0)
       return 0;
    CAN_Receive(CAN1, CAN_FIFO0, &RxMsg);
    len = RxMsg.Data[0];
    for(i = 0; i < len / 8 + ((len % 8) ? 1 : 0); i++)
    {
       if(CAN_MessagePending(CAN1, CAN_FIFO0) == 0)
           return 0;
       CAN_Receive(CAN1, CAN_FIFO0, &RxMsg);
       for(j = 0; j < (((len - 8 * i) < 8) ? (len % 8) : 8); j++)
           buf[i * 8 + j] = RxMsg.Data[j];
    }

    return len;       */
    u8 i;

    for(i = 0; i < RxPKG_SIZE; i++) {
        longbuf[i] = CanRxBuf[i];
        CanRxBuf[i] = 0;
    }
}

/**
  * @intro      config slave address
  * @param      u8 slave_addr
  * @retval     none
  */
void CAN_AddrConfig(u8 slave_addr)
{
    CAN_FilterInitTypeDef  CAN_FilterInitStructure;

    CAN_FilterInitStructure.CAN_FilterNumber = 0;
    CAN_FilterInitStructure.CAN_FilterMode = CAN_FilterMode_IdMask;
    CAN_FilterInitStructure.CAN_FilterScale = CAN_FilterScale_32bit;
//  printf("\n\rSlave Addr = %x\n\r", slave_addr);

    CAN_FilterInitStructure.CAN_FilterIdHigh = (slave_addr << 8);
    printf("\n\rFilterIdHigh = %x\n\r", CAN_FilterInitStructure.CAN_FilterIdHigh);
    CAN_FilterInitStructure.CAN_FilterIdLow = 0 | CAN_ID_STD;
//  printf("\n\rFilterIdLow = %x\n\r", CAN_FilterInitStructure.CAN_FilterIdLow);

    CAN_FilterInitStructure.CAN_FilterMaskIdHigh = 0xff00;
//  printf("\n\rFilterMaskIdHigh = %x\n\r", CAN_FilterInitStructure.CAN_FilterMaskIdHigh);
    CAN_FilterInitStructure.CAN_FilterMaskIdLow = 0x0000;
//  printf("\n\rFilterMaskIdLow = %x\n\r", CAN_FilterInitStructure.CAN_FilterMaskIdLow);

    CAN_FilterInitStructure.CAN_FilterFIFOAssignment = CAN_Filter_FIFO0;

    CAN_FilterInitStructure.CAN_FilterActivation = ENABLE;

    CAN_FilterInit(&CAN_FilterInitStructure);
}



//WIFI�����жϷ�����
void CAN1_RX0_IRQHandler(void)
{
    int i;
    CanRxMsg m_RxMsg;
//  printf("\r\ncan: baka test\n\r");
    CAN_Receive(CAN1, CAN_FIFO0, &m_RxMsg);

    if(bufStatus && !(m_RxMsg.StdId & 0x7)) {
        for(i = 0; i < 8; i++) {
            CanRxBuf[bufPointer] = m_RxMsg.Data[i];
            bufPointer ++;

            if(bufPointer == RxPKG_SIZE) {
                bufStatus = 0;
                bufPointer = 0;
                break;
            }
        }
    }

    if((m_RxMsg.StdId & 0x7) == CAN_ADDR) {
        CAN_AddrConfig(m_RxMsg.Data[0]);
    }

    /* �Ƚ����ݱ�ͷ */
    if((bufStatus == 0) && (RxMessage[0] == 0xAA) && (RxMessage[1] == 0x80)) {
        /*      switch(RxMessage[3])
            {
                case    0x04:
        //              ExtLED_ON;
                        SetRunningStatus(PRERUNNING_DIAN_HUO_ONE);
                        break;

                case    0x05:
                        TIM4_ForIgniteStart();
                        break;

                case    0x06:
        //              ExtLED_FlashForKeepingWarm();
                        SetRunningStatus(KEEPINGWARM);
                        break;

                case    0x07:
                        SetRunningStatus(WAITTINGCOMMAND);
                        break;

                case    0x12:
                        PumpSpeedDec();
                        break;

                case    0x13:
                        PumpSpeedInc();
                        break;

                case    0x16:
                        HydrgFanSpdInc();
                        break;

                case    0x17:
                        HydrgFanSpdDec();
                        break;

                case    0x08:
        //              CAN_SendMsg(CAN_TXMSG4);
                        break;
            }*/
    }
}


/**************************END OF FILE************************************/

