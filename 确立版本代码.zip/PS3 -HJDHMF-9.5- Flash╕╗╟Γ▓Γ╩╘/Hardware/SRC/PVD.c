#include "include.h"
#include "pvd.h"

void PVD_Configuration(void)
{
    EXTI_InitTypeDef EXTI_InitStructure;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR, ENABLE);

    EXTI_ClearITPendingBit(EXTI_Line16);
    EXTI_InitStructure.EXTI_Line = EXTI_Line16;
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);

    PVD_ProtectStatuCmd(ON);                            //�����籣��

    PWR_PVDLevelConfig(PWR_PVDLevel_2V9);   //PVD̽���ѹ��ֵ2.9V
    PWR_PVDCmd(ENABLE);                                     //ʹ�ܿɱ�̵ĵ�ѹ̽����
}

void PVD_ProtectStatuCmd(SYSTEM_SWITCH_VARIABLES_STATU_Typedef i_NewStatu)
{
    NVIC_InitTypeDef NVIC_InitStructure;

    NVIC_InitStructure.NVIC_IRQChannel = PVD_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;

    if(i_NewStatu == ON) {
        NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    } else {
        NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;//DISABLE;
    }

    NVIC_Init(&NVIC_InitStructure);
}


