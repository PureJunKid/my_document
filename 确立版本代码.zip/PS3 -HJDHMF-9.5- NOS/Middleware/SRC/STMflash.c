#include "include.h"

GET_PARAMETERS_SOURCE_Typedef enGET_PARAMETERS_SOURCE_FLAG;             //size = 1,���ȡĬ��ֵ�ı�־��Ϊö������
//��������洢��־��ֵͨ������SelectParameterSource()
//��SetAndSaveParameterSourceSelectFlag()�趨�Ͷ�ȡ
//size = 13
REFORMINGROOM_TEMP_LINES_Typedef stREFORMINGROOM_TEMP_TABLE;            //size = 4
HYDRAULIC_PRESSURE_LINES_Typedef stHYDRAULIC_PRESSURE_TABLE;            //size = 3
SYSTEM_TEMPS_Typedef stSYSTEM_TEMP = {0};                                     //size = 2*3
BELOWER_ADJUST_PARAMETER_Typedef stDIANHUOING_1_ADJUST_PARAMETER[3];         //size = 2*2
BELOWER_ADJUST_PARAMETER_Typedef stDIANHUOING_2_ADJUST_PARAMETER[2];         //size = 3
TIMES_FOR_IGNITIONCHECK_Typedef stSYSTEM_IGNITIONCHECK;                 //size = 12
uint16_t PUMP_PRESSURE_OUTPUT[2];                                      //size = 4*8
AIR_PARAMETER_OF_POWERS_Typedef stPowerValue[8];                        //size = 1
uint16_t CENTRIFUGAL_RATIO_IFABOVE_POWER8;                              //size = 1
uint16_t CENTRIFUGAL_RATIO_IFABOVE_TEMP60;                              //size = 2*1
HEAT_AND_FLAME_TEMP_Typedef stHEAT_AND_FLAME_TEMP_TABLE;                //size = 3*1

uint8_t g_u8PumpAdjLqdPrssTab;
uint8_t g_u8PumpRunSpdAfterAdj;

uint16_t RW_Buffer[BUFFER_SIZE];
uint16_t W_Buffer[BUFFER_SIZE];


#if 1
void LoadParameters(void)
{
    if(GET_STORED_PARAMETERS == SelectParameterSource()) {
        GetStoredParameters();
    } else {
        GetDefaultParameter();
    }
}

GET_PARAMETERS_SOURCE_Typedef SelectParameterSource(void)
{
    u16 m_RW_Buffer;
    STMFLASH_Read(FLASH_SAVE_ADDR, & m_RW_Buffer, 1);

    if(m_RW_Buffer == 0) {
        enGET_PARAMETERS_SOURCE_FLAG = GET_DEFAULT_PARAMETERS;
    } else {
        enGET_PARAMETERS_SOURCE_FLAG = GET_STORED_PARAMETERS;
    }

    enGET_PARAMETERS_SOURCE_FLAG = GET_DEFAULT_PARAMETERS;
#ifdef TEST_MODE
//  printf("----> get default parameters!<---------\r\n");
#endif
    return enGET_PARAMETERS_SOURCE_FLAG;
}

void SetAndSaveParameterSourceSelectFlag(GET_PARAMETERS_SOURCE_Typedef m_enGET_PARAMETERS_SOURCE_SELECT)
{
    u16 m_RW_Buffer;

    if(m_enGET_PARAMETERS_SOURCE_SELECT == GET_DEFAULT_PARAMETERS) {
        m_RW_Buffer = 0;
    } else {
        m_RW_Buffer = 1;
    }

    STMFLASH_Write(FLASH_SAVE_ADDR, & m_RW_Buffer, 1);
}

//����Flash����
void SaveParameters(void)
{
//  u16 RW_Buffer[BUFFER_SIZE - 1 ];
    RW_Buffer[0] = stREFORMINGROOM_TEMP_TABLE.StartTempLevel;
    RW_Buffer[1] = stREFORMINGROOM_TEMP_TABLE.LowerLimitHeatKeeping;
    RW_Buffer[2] = stREFORMINGROOM_TEMP_TABLE.UpperLimitHeatKeeping;
    RW_Buffer[3] = stREFORMINGROOM_TEMP_TABLE.LowerLimitRunningAlarmTemp;
    RW_Buffer[4] = stREFORMINGROOM_TEMP_TABLE.UpperLimitRunningAlarmTemp;
    RW_Buffer[5] = stREFORMINGROOM_TEMP_TABLE.LowerLimitPowerDown;
    RW_Buffer[6] = stREFORMINGROOM_TEMP_TABLE.UpperLimitPowerDown;
    RW_Buffer[7] = stREFORMINGROOM_TEMP_TABLE.ForPumpAdjustLine1;
    RW_Buffer[8] = stREFORMINGROOM_TEMP_TABLE.ForPumpAdjustLine2;
    RW_Buffer[9] = stREFORMINGROOM_TEMP_TABLE.ForPumpAdjustLine3;
    RW_Buffer[10] = stREFORMINGROOM_TEMP_TABLE.ForPumpAdjustLine4;
    RW_Buffer[11] = stREFORMINGROOM_TEMP_TABLE.ForPumpAdjustLine5;
    RW_Buffer[12] = stREFORMINGROOM_TEMP_TABLE.ForPumpAdjustLine6;

    RW_Buffer[13] = stHYDRAULIC_PRESSURE_TABLE.ForPumpAdjustLine1;
    RW_Buffer[14] = stHYDRAULIC_PRESSURE_TABLE.ForPumpAdjustLine2;
    RW_Buffer[15] = stHYDRAULIC_PRESSURE_TABLE.ForPumpAdjustLine3;
    RW_Buffer[16] = stHYDRAULIC_PRESSURE_TABLE.ForPumpAdjustLine4;
    /*
        RW_Buffer[17] = stSYSTEM_TEMP.ReformingRoom;
        RW_Buffer[18] = stSYSTEM_TEMP.HeatingRod;
        RW_Buffer[19] = stSYSTEM_TEMP.Flame;
    */
    RW_Buffer[20] = stDIANHUOING_1_ADJUST_PARAMETER[0].TimeForWaittingAdjust;
    RW_Buffer[21] = stDIANHUOING_1_ADJUST_PARAMETER[0].Ratio;
    RW_Buffer[22] = stDIANHUOING_1_ADJUST_PARAMETER[1].TimeForWaittingAdjust;
    RW_Buffer[23] = stDIANHUOING_1_ADJUST_PARAMETER[1].Ratio;
    RW_Buffer[24] = stDIANHUOING_1_ADJUST_PARAMETER[2].TimeForWaittingAdjust;
    RW_Buffer[25] = stDIANHUOING_1_ADJUST_PARAMETER[2].Ratio;

    RW_Buffer[26] = stDIANHUOING_2_ADJUST_PARAMETER[0].TimeForWaittingAdjust;
    RW_Buffer[27] = stDIANHUOING_2_ADJUST_PARAMETER[0].Ratio;
    RW_Buffer[28] = stDIANHUOING_2_ADJUST_PARAMETER[1].TimeForWaittingAdjust;
    RW_Buffer[29] = stDIANHUOING_2_ADJUST_PARAMETER[1].Ratio;

    RW_Buffer[30] = stSYSTEM_IGNITIONCHECK.HoldTimeWhenHeating;
    RW_Buffer[31] = stSYSTEM_IGNITIONCHECK.HoldTimeWhenRunning;
    RW_Buffer[32] = stSYSTEM_IGNITIONCHECK.CheckTime;

    RW_Buffer[33] = PUMP_PRESSURE_OUTPUT[0];
    RW_Buffer[34] = PUMP_PRESSURE_OUTPUT[1];

    RW_Buffer[45] = stPowerValue[0].Power;
    RW_Buffer[46] = stPowerValue[1].Power;
    RW_Buffer[47] = stPowerValue[2].Power;
    RW_Buffer[48] = stPowerValue[3].Power;
    RW_Buffer[49] = stPowerValue[4].Power;
    RW_Buffer[50] = stPowerValue[5].Power;
    RW_Buffer[51] = stPowerValue[6].Power;
    RW_Buffer[52] = stPowerValue[7].Power;

    RW_Buffer[53] = stPowerValue[0].TimeForAirOutCycle;
    RW_Buffer[54] = stPowerValue[0].TimeForAirOutEveryCycle;
    RW_Buffer[55] = stPowerValue[0].RatioOfAirBlower;

    RW_Buffer[56] = stPowerValue[1].TimeForAirOutCycle;
    RW_Buffer[57] = stPowerValue[1].TimeForAirOutEveryCycle;
    RW_Buffer[58] = stPowerValue[1].RatioOfAirBlower;

    RW_Buffer[59] = stPowerValue[2].TimeForAirOutCycle;
    RW_Buffer[60] = stPowerValue[2].TimeForAirOutEveryCycle;
    RW_Buffer[61] = stPowerValue[2].RatioOfAirBlower;

    RW_Buffer[62] = stPowerValue[3].TimeForAirOutCycle;
    RW_Buffer[63] = stPowerValue[3].TimeForAirOutEveryCycle;
    RW_Buffer[64] = stPowerValue[3].RatioOfAirBlower;

    RW_Buffer[65] = stPowerValue[4].TimeForAirOutCycle;
    RW_Buffer[66] = stPowerValue[4].TimeForAirOutEveryCycle;
    RW_Buffer[67] = stPowerValue[4].RatioOfAirBlower;

    RW_Buffer[68] = stPowerValue[5].TimeForAirOutCycle;
    RW_Buffer[69] = stPowerValue[5].TimeForAirOutEveryCycle;
    RW_Buffer[70] = stPowerValue[5].RatioOfAirBlower;

    RW_Buffer[71] = stPowerValue[6].TimeForAirOutCycle;
    RW_Buffer[72] = stPowerValue[6].TimeForAirOutEveryCycle;
    RW_Buffer[73] = stPowerValue[6].RatioOfAirBlower;

    RW_Buffer[74] = stPowerValue[7].TimeForAirOutCycle;
    RW_Buffer[75] = stPowerValue[7].TimeForAirOutEveryCycle;
    RW_Buffer[76] = stPowerValue[7].RatioOfAirBlower;

    RW_Buffer[77] = CENTRIFUGAL_RATIO_IFABOVE_POWER8;
    RW_Buffer[78] = CENTRIFUGAL_RATIO_IFABOVE_TEMP60;

    RW_Buffer[79] = stHEAT_AND_FLAME_TEMP_TABLE.HeatingRodTemp;
    RW_Buffer[80] = stHEAT_AND_FLAME_TEMP_TABLE.FlameTemp_1;
    RW_Buffer[81] = stHEAT_AND_FLAME_TEMP_TABLE.FlameTemp_2;

    STMFLASH_Write(FLASH_SAVE_ADDR + 2, RW_Buffer, BUFFER_SIZE);
}

//��ȡflash����
void GetStoredParameters(void)
{
//  u16 RW_Buffer[BUFFER_SIZE - 1 ];
    STMFLASH_Read(FLASH_SAVE_ADDR + 2, RW_Buffer, BUFFER_SIZE);
    stREFORMINGROOM_TEMP_TABLE.StartTempLevel = RW_Buffer[0];
    stREFORMINGROOM_TEMP_TABLE.LowerLimitHeatKeeping = RW_Buffer[1];
    stREFORMINGROOM_TEMP_TABLE.UpperLimitHeatKeeping = RW_Buffer[2];
    stREFORMINGROOM_TEMP_TABLE.LowerLimitRunningAlarmTemp = RW_Buffer[3];
    stREFORMINGROOM_TEMP_TABLE.UpperLimitRunningAlarmTemp = RW_Buffer[4];
    stREFORMINGROOM_TEMP_TABLE.LowerLimitPowerDown = RW_Buffer[5];
    stREFORMINGROOM_TEMP_TABLE.UpperLimitPowerDown = RW_Buffer[6];
    stREFORMINGROOM_TEMP_TABLE.ForPumpAdjustLine1 = RW_Buffer[7];
    stREFORMINGROOM_TEMP_TABLE.ForPumpAdjustLine2 = RW_Buffer[8];
    stREFORMINGROOM_TEMP_TABLE.ForPumpAdjustLine3 = RW_Buffer[9];
    stREFORMINGROOM_TEMP_TABLE.ForPumpAdjustLine4 = RW_Buffer[10];
    stREFORMINGROOM_TEMP_TABLE.ForPumpAdjustLine5 = RW_Buffer[11];
    stREFORMINGROOM_TEMP_TABLE.ForPumpAdjustLine6 = RW_Buffer[12];

    stHYDRAULIC_PRESSURE_TABLE.ForPumpAdjustLine1 = RW_Buffer[13];
    stHYDRAULIC_PRESSURE_TABLE.ForPumpAdjustLine2 = RW_Buffer[14];
    stHYDRAULIC_PRESSURE_TABLE.ForPumpAdjustLine3 = RW_Buffer[15];
    stHYDRAULIC_PRESSURE_TABLE.ForPumpAdjustLine4 = RW_Buffer[16];
    /*
        stSYSTEM_TEMP.ReformingRoom = RW_Buffer[17];
        stSYSTEM_TEMP.HeatingRod = RW_Buffer[18];
        stSYSTEM_TEMP.Flame = RW_Buffer[19];
    */
    stDIANHUOING_1_ADJUST_PARAMETER[0].TimeForWaittingAdjust = RW_Buffer[20];
    stDIANHUOING_1_ADJUST_PARAMETER[0].Ratio = RW_Buffer[21];
    stDIANHUOING_1_ADJUST_PARAMETER[1].TimeForWaittingAdjust = RW_Buffer[22];
    stDIANHUOING_1_ADJUST_PARAMETER[1].Ratio = RW_Buffer[23];
    stDIANHUOING_1_ADJUST_PARAMETER[2].TimeForWaittingAdjust = RW_Buffer[24];
    stDIANHUOING_1_ADJUST_PARAMETER[2].Ratio = RW_Buffer[25];

    stDIANHUOING_2_ADJUST_PARAMETER[0].TimeForWaittingAdjust = RW_Buffer[26];
    stDIANHUOING_2_ADJUST_PARAMETER[0].Ratio = RW_Buffer[27];
    stDIANHUOING_2_ADJUST_PARAMETER[1].TimeForWaittingAdjust = RW_Buffer[28];
    stDIANHUOING_2_ADJUST_PARAMETER[1].Ratio = RW_Buffer[29];

    stSYSTEM_IGNITIONCHECK.HoldTimeWhenHeating = RW_Buffer[30];
    stSYSTEM_IGNITIONCHECK.HoldTimeWhenRunning = RW_Buffer[31];
    stSYSTEM_IGNITIONCHECK.CheckTime = RW_Buffer[32];

    PUMP_PRESSURE_OUTPUT[0] = RW_Buffer[33];
    PUMP_PRESSURE_OUTPUT[1] = RW_Buffer[34];


    stPowerValue[0].Power = RW_Buffer[45];
    stPowerValue[1].Power = RW_Buffer[46];
    stPowerValue[2].Power = RW_Buffer[47];
    stPowerValue[3].Power = RW_Buffer[48];
    stPowerValue[4].Power = RW_Buffer[49];
    stPowerValue[5].Power = RW_Buffer[50];
    stPowerValue[6].Power = RW_Buffer[51];
    stPowerValue[7].Power = RW_Buffer[52];

    stPowerValue[0].TimeForAirOutCycle = RW_Buffer[53];
    stPowerValue[0].TimeForAirOutEveryCycle = RW_Buffer[54];
    stPowerValue[0].RatioOfAirBlower = RW_Buffer[55];

    stPowerValue[1].TimeForAirOutCycle = RW_Buffer[56];
    stPowerValue[1].TimeForAirOutEveryCycle = RW_Buffer[57];
    stPowerValue[1].RatioOfAirBlower = RW_Buffer[58];

    stPowerValue[2].TimeForAirOutCycle = RW_Buffer[59];
    stPowerValue[2].TimeForAirOutEveryCycle = RW_Buffer[60];
    stPowerValue[2].RatioOfAirBlower = RW_Buffer[61];

    stPowerValue[3].TimeForAirOutCycle = RW_Buffer[62];
    stPowerValue[3].TimeForAirOutEveryCycle = RW_Buffer[63];
    stPowerValue[3].RatioOfAirBlower = RW_Buffer[64];

    stPowerValue[4].TimeForAirOutCycle = RW_Buffer[65];
    stPowerValue[4].TimeForAirOutEveryCycle = RW_Buffer[66];
    stPowerValue[4].RatioOfAirBlower = RW_Buffer[67];

    stPowerValue[5].TimeForAirOutCycle = RW_Buffer[68];
    stPowerValue[5].TimeForAirOutEveryCycle = RW_Buffer[69];
    stPowerValue[5].RatioOfAirBlower = RW_Buffer[70];

    stPowerValue[6].TimeForAirOutCycle = RW_Buffer[71];
    stPowerValue[6].TimeForAirOutEveryCycle = RW_Buffer[72];
    stPowerValue[6].RatioOfAirBlower = RW_Buffer[73];

    stPowerValue[7].TimeForAirOutCycle = RW_Buffer[74];
    stPowerValue[7].TimeForAirOutEveryCycle = RW_Buffer[75];
    stPowerValue[7].RatioOfAirBlower = RW_Buffer[76];

    CENTRIFUGAL_RATIO_IFABOVE_POWER8 = RW_Buffer[77];
    CENTRIFUGAL_RATIO_IFABOVE_TEMP60 = RW_Buffer[78];

    stHEAT_AND_FLAME_TEMP_TABLE.HeatingRodTemp = RW_Buffer[79];
    stHEAT_AND_FLAME_TEMP_TABLE.FlameTemp_1 = RW_Buffer[80];
    stHEAT_AND_FLAME_TEMP_TABLE.FlameTemp_2 = RW_Buffer[81];

}


//ʹ��Ĭ�ϲ���
void GetDefaultParameter(void)
{
#ifdef TEST_MODE
//  printf("------>Setting default parameters!<-------\r\n");
#endif
    stREFORMINGROOM_TEMP_TABLE.StartTempLevel = 180;//160;
    stREFORMINGROOM_TEMP_TABLE.LowerLimitHeatKeeping = 375;
    stREFORMINGROOM_TEMP_TABLE.UpperLimitHeatKeeping = 385;
    stREFORMINGROOM_TEMP_TABLE.LowerLimitRunningAlarmTemp = 110;
    stREFORMINGROOM_TEMP_TABLE.UpperLimitRunningAlarmTemp = 450;
    stREFORMINGROOM_TEMP_TABLE.LowerLimitPowerDown = 105;
    stREFORMINGROOM_TEMP_TABLE.UpperLimitPowerDown = 460;
    stREFORMINGROOM_TEMP_TABLE.ForPumpAdjustLine1 = 0;
    stREFORMINGROOM_TEMP_TABLE.ForPumpAdjustLine2 = 0;
    stREFORMINGROOM_TEMP_TABLE.ForPumpAdjustLine3 = 0;
    stREFORMINGROOM_TEMP_TABLE.ForPumpAdjustLine4 = 0;
    stREFORMINGROOM_TEMP_TABLE.ForPumpAdjustLine5 = 0;
    stREFORMINGROOM_TEMP_TABLE.ForPumpAdjustLine6 = 0;

    stHYDRAULIC_PRESSURE_TABLE.ForPumpAdjustLine1 = 0;
    stHYDRAULIC_PRESSURE_TABLE.ForPumpAdjustLine2 = 0;
    stHYDRAULIC_PRESSURE_TABLE.ForPumpAdjustLine3 = 0;
    stHYDRAULIC_PRESSURE_TABLE.ForPumpAdjustLine4 = 0;

    /*
        stSYSTEM_TEMP.ReformingRoom = x;
        stSYSTEM_TEMP.HeatingRod = x;
        stSYSTEM_TEMP.Flame = x;
    */

    stDIANHUOING_1_ADJUST_PARAMETER[0].TimeForWaittingAdjust = 30;
    stDIANHUOING_1_ADJUST_PARAMETER[0].Ratio = 70;
    stDIANHUOING_1_ADJUST_PARAMETER[1].TimeForWaittingAdjust = 90;
    stDIANHUOING_1_ADJUST_PARAMETER[1].Ratio = 100;
    stDIANHUOING_1_ADJUST_PARAMETER[2].TimeForWaittingAdjust = 150;
    stDIANHUOING_1_ADJUST_PARAMETER[2].Ratio = 200;

    stDIANHUOING_2_ADJUST_PARAMETER[0].TimeForWaittingAdjust = 30;
    stDIANHUOING_2_ADJUST_PARAMETER[0].Ratio = 70;
    stDIANHUOING_2_ADJUST_PARAMETER[1].TimeForWaittingAdjust = 90;
    stDIANHUOING_2_ADJUST_PARAMETER[1].Ratio = 200;

    stSYSTEM_IGNITIONCHECK.HoldTimeWhenHeating = 120;
    stSYSTEM_IGNITIONCHECK.HoldTimeWhenRunning = 120;
    stSYSTEM_IGNITIONCHECK.CheckTime = 180;

    PUMP_PRESSURE_OUTPUT[0] = 17;//18;//��һ�ε��ʱ�ı���
    PUMP_PRESSURE_OUTPUT[1] = 37;//36;    //�ڶ��ε��ʱ�ı���

    g_u8PumpAdjLqdPrssTab = 4;          //��ʼ�Զ�����ѹ��ѹ��ֵ��kg/cm^2Ϊ��λ��
    g_u8PumpRunSpdAfterAdj = 41;//28;       //Һѹ�ﵽ4KG����ٵ���Ŀ��ֵ

    stPowerValue[0].Power = 500;
    stPowerValue[1].Power = 1000;
    stPowerValue[2].Power = 1500;
    stPowerValue[3].Power = 2000;
    stPowerValue[4].Power = 600;
    stPowerValue[5].Power = 1000;
    stPowerValue[6].Power = 1500;
    stPowerValue[7].Power = 2000;

    //msΪ��λ
    stPowerValue[0].TimeForAirOutCycle = 30000;
    stPowerValue[0].TimeForAirOutEveryCycle = 500;
    stPowerValue[0].RatioOfAirBlower = 0;
    stPowerValue[1].TimeForAirOutCycle = 25000;
    stPowerValue[1].TimeForAirOutEveryCycle = 500;
    stPowerValue[1].RatioOfAirBlower = 0;
    stPowerValue[2].TimeForAirOutCycle = 20000;
    stPowerValue[2].TimeForAirOutEveryCycle = 500;
    stPowerValue[2].RatioOfAirBlower = 0;
    stPowerValue[3].TimeForAirOutCycle = 15000;
    stPowerValue[3].TimeForAirOutEveryCycle = 500;
    stPowerValue[3].RatioOfAirBlower = 0;
    stPowerValue[4].TimeForAirOutCycle = 13000;
    stPowerValue[4].TimeForAirOutEveryCycle = 500;
    stPowerValue[4].RatioOfAirBlower = 70;  //RW5����ʱ���ռ�ձ� 35%
    stPowerValue[5].TimeForAirOutCycle = 0;
    stPowerValue[5].TimeForAirOutEveryCycle = 0;
    stPowerValue[5].RatioOfAirBlower = 90;
    stPowerValue[6].TimeForAirOutCycle = 0;
    stPowerValue[6].TimeForAirOutEveryCycle = 0;
    stPowerValue[6].RatioOfAirBlower = 120;
    stPowerValue[7].TimeForAirOutCycle = 0;
    stPowerValue[7].TimeForAirOutEveryCycle = 0;
    stPowerValue[7].RatioOfAirBlower = 130;

    CENTRIFUGAL_RATIO_IFABOVE_POWER8 = 160;
    CENTRIFUGAL_RATIO_IFABOVE_TEMP60 = 160;

//  stHEAT_AND_FLAME_TEMP_TABLE.HeatingRodTemp = RW_Buffer[79];
    stHEAT_AND_FLAME_TEMP_TABLE.FlameTemp_1 = 160;
    stHEAT_AND_FLAME_TEMP_TABLE.FlameTemp_2 = 300;
}

//��ȡָ����ַ�İ���(16λ����)
//faddr:����ַ(�˵�ַ����Ϊ2�ı���!!)
//����ֵ:��Ӧ����.
u16 STMFLASH_ReadHalfWord(u32 faddr)
{
    return *(vu16 *)faddr;
}
#if STM32_FLASH_WREN    //���ʹ����д   
//������д��
//WriteAddr:��ʼ��ַ
//pBuffer:����ָ��
//NumToWrite:����(16λ)��
void STMFLASH_Write_NoCheck(u32 WriteAddr, u16 *pBuffer, u16 NumToWrite)
{
    u16 i;

    for(i = 0; i < NumToWrite; i++) {
        FLASH_ProgramHalfWord(WriteAddr, pBuffer[i]);
        WriteAddr += 2;//��ַ����2.
    }
}
//��ָ����ַ��ʼд��ָ�����ȵ�����
//WriteAddr:��ʼ��ַ(�˵�ַ����Ϊ2�ı���!!)
//pBuffer:����ָ��
//NumToWrite:����(16λ)��(����Ҫд���16λ���ݵĸ���.)
#if STM32_FLASH_SIZE<256
    #define STM_SECTOR_SIZE 1024 //�ֽ�
#else
    #define STM_SECTOR_SIZE 2048
#endif
u16 STMFLASH_BUF[STM_SECTOR_SIZE / 2]; //�����2K�ֽ�
void STMFLASH_Write(u32 WriteAddr, u16 *pBuffer, u16 NumToWrite)
{
    u32 secpos;    //������ַ
    u16 secoff;    //������ƫ�Ƶ�ַ(16λ�ּ���)
    u16 secremain; //������ʣ���ַ(16λ�ּ���)
    u16 i;
    u32 offaddr;   //ȥ��0X08000000��ĵ�ַ

    if(WriteAddr < STM32_FLASH_BASE || (WriteAddr >= (STM32_FLASH_BASE + 1024 * STM32_FLASH_SIZE))) {
        return;    //�Ƿ���ַ
    }

    FLASH_Unlock();                     //����
    offaddr = WriteAddr - STM32_FLASH_BASE; //ʵ��ƫ�Ƶ�ַ.
    secpos = offaddr / STM_SECTOR_SIZE;     //������ַ  0~127 for STM32F103RBT6
    secoff = (offaddr % STM_SECTOR_SIZE) / 2; //�������ڵ�ƫ��(2���ֽ�Ϊ������λ.)
    secremain = STM_SECTOR_SIZE / 2 - secoff; //����ʣ��ռ��С

    if(NumToWrite <= secremain) {
        secremain = NumToWrite;    //�����ڸ�������Χ
    }

    while(1) {
        STMFLASH_Read(secpos * STM_SECTOR_SIZE + STM32_FLASH_BASE, STMFLASH_BUF, STM_SECTOR_SIZE / 2); //������������������

        for(i = 0; i < secremain; i++) { //У������
            if(STMFLASH_BUF[secoff + i] != 0XFFFF) {
                break;    //��Ҫ����
            }
        }

        if(i < secremain) { //��Ҫ����
            FLASH_ErasePage(secpos * STM_SECTOR_SIZE + STM32_FLASH_BASE); //�����������

            for(i = 0; i < secremain; i++) { //����
                STMFLASH_BUF[i + secoff] = pBuffer[i];
            }

            STMFLASH_Write_NoCheck(secpos * STM_SECTOR_SIZE + STM32_FLASH_BASE, STMFLASH_BUF, STM_SECTOR_SIZE / 2); //д����������
        } else {
            STMFLASH_Write_NoCheck(WriteAddr, pBuffer, secremain);    //д�Ѿ������˵�,ֱ��д������ʣ������.
        }

        if(NumToWrite == secremain) {
            break;    //д�������
        } else { //д��δ����
            secpos++;               //������ַ��1
            secoff = 0;             //ƫ��λ��Ϊ0
            pBuffer += secremain;   //ָ��ƫ��
            WriteAddr += secremain; //д��ַƫ��
            NumToWrite -= secremain; //�ֽ�(16λ)���ݼ�

            if(NumToWrite > (STM_SECTOR_SIZE / 2)) {
                secremain = STM_SECTOR_SIZE / 2;    //��һ����������д����
            } else {
                secremain = NumToWrite;    //��һ����������д����
            }
        }
    };

    FLASH_Lock();//����
}
#endif

//��ָ����ַ��ʼ����ָ�����ȵ�����
//ReadAddr:��ʼ��ַ
//pBuffer:����ָ��
//NumToWrite:����(16λ)��
void STMFLASH_Read(u32 ReadAddr, u16 *pBuffer, u16 NumToRead)
{
    u16 i;

    for(i = 0; i < NumToRead; i++) {
        pBuffer[i] = STMFLASH_ReadHalfWord(ReadAddr); //��ȡ2���ֽ�.
        ReadAddr += 2; //ƫ��2���ֽ�.
    }
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
//WriteAddr:��ʼ��ַ
//WriteData:Ҫд�������
void Test_Write(u32 WriteAddr, u16 WriteData)
{
    STMFLASH_Write(WriteAddr, &WriteData, 1); //д��һ����
}

#endif















