#include "include.h"

//SYSTEM_START_MODE_Typedef enSTARTMODE = DIRECT;

/*
void SetStartMode(SYSTEM_START_MODE_Typedef m_NEW_MODE_STATU)
{
    enSTARTMODE = m_NEW_MODE_STATU;
}
*/

u16 g_u16StartRemainSecond = 15 * 60;

//����Ϊ�����׶δ���
void PreRunning(void)
{
    float DianHuoCheckTable1, GoToNextStepTempTable1;
    float DianHuoCheckTable2, GoToNextStepTempTable2;

    DianHuoCheckTable1 = stHEAT_AND_FLAME_TEMP_TABLE.FlameTemp_1;//K3-1
    GoToNextStepTempTable1 = stREFORMINGROOM_TEMP_TABLE.StartTempLevel;//K1-1

    PVD_ProtectStatuCmd(ON);

    ResetH2MakeTimeThisTime();

    if((PASS == DianHuoFirstTimeCheck(DianHuoCheckTable1, GoToNextStepTempTable1, 3/*�ظ����������*/, 1))) {
        SetRunningStatus(PRERUNNING_DIAN_HUO_TWO);
    } else {
//      printf("the dianhuo first time program has been break or failed!<---\r\n");
        if(GetRunningStatus() != WAITTINGCOMMAND) {   //������Ϊ��λ��ֱ�ӽ�״̬��Ϊ�ر��£����µ��ʧ��
            SoftPowerOff();
            SetRunningStatus(KEEPINGWARM);
        }
    }

    if(GetRunningStatus() == PRERUNNING_DIAN_HUO_TWO) {
        DianHuoCheckTable2 = stHEAT_AND_FLAME_TEMP_TABLE.FlameTemp_2;
        GoToNextStepTempTable2 = 0;//��009.1һ����������ã�����Ϊ0

        if(PASS != DianHuoSecondTimeCheck(DianHuoCheckTable2, GoToNextStepTempTable2/*��009.1һ�����������*/, 3, 1)) {
            if(GetRunningStatus() != WAITTINGCOMMAND) {   //������Ϊ��λ��ֱ�ӽ�״̬��Ϊ�ر��£����µ��ʧ��
                SoftPowerOff();
                SetRunningStatus(KEEPINGWARM);
            }

//          printf("the dianhuo second time program has been break or failed!<---\r\n");
        } else {
            SetRunningStatus(RUNNING);
        }
    }
}
DIAN_HUO_CHECK_STATU_Typedef DianHuoFirstTimeCheck(float m_DianHuoCheckTable1, float m_GoToNextStepTempTable1, uint8_t maxtrytime, uint8_t m_CheckDelayTimeFlag)
{
//  uint8_t i;
    DIAN_HUO_CHECK_STATU_Typedef m_enDIAN_HUO_CHECK_STATU;
//  float m_FireTemp;
//  float m_RefromRoomTemp;
    u8 m_u8HydrgFanCtrlSpd;
    u8 m_u8HydrgFanSpeedUpFirstFinishFlag = NO;
    u8 m_u8HydrgFanSpeedUpSecondFinishFlag = NO;
    SYSTEM_TIME_Typedef m_stSYSTEM_TIME_RECORD_FOR_TEMP_CHECK;
    SYSTEM_TIME_Typedef m_stCURRENT_SYSTEM_TIME;
//  SYSTEM_TIME_Typedef m_stSystemTimeForFastHeater;
//  SYSTEM_TIME_Typedef m_stCurrentSystemTime;

    SystemRunningTimesInc();
    printf("dianhuo first time!<--\r\n");

//  HeaterON;
//  printf("delay for 3min!<----\r\n");
    /*
    if(Delay_BREAK == Delay_s(180,PRERUNNING_DIAN_HUO_ONE))
    {
        SoftPowerOff();
        return FAILED;
    }
    */
//  m_stSystemTimeForFastHeater = GetSystemTime();
    /*
        while(1)
        {
            m_FireTemp = GetFireTemp();
            printf("FireTemp is %f!<---\r\n", m_FireTemp);
            m_stCurrentSystemTime = GetSystemTime();
            if(((m_stCurrentSystemTime.hour - m_stSystemTimeForFastHeater.hour)*60
                                    + m_stCurrentSystemTime.minute - m_stSystemTimeForFastHeater.minute)
                                    >= 3)        //3������δ�����¶ȵ�ָ���¶�
            {
                break;
            }
            if(m_FireTemp >= 247)
            {
                break;
            }
        }//while(m_FireTemp < 247);
    */

    MagneticValve1ON;   //��Һ��ŷ�1��
    SetHydrgPumpSpd(PUMP_PRESSURE_OUTPUT[0]);//ˮ�õ��ڿ��Ƶ�ѹ
    SetHydrgFanSpd(40);
//    SetHydrgFanSpd(0);
    IgniterON;
    TIM2_ForIgniteStart();//2���Ӻ�رյ����

    /*  for(i = 0; i < maxtrytime; i++)
        {
            printf("the %d try time during the first time dianhuo!<----\r\n", i + 1);
            IgniterON;
            TIM2_ForIgniteStart();//2���Ӻ�رյ����
    //      StartTIM6(Igniter_DELAY_120S_OFF, 1000 * stSYSTEM_IGNITIONCHECK.HoldTimeWhenHeating);
            printf("delay for first time airBlower adjust in the first time dianhuo begin!<---\r\n");
            if(Delay_BREAK == Delay_s(stDIANHUOING_1_ADJUST_PARAMETER[0].TimeForWaittingAdjust, PRERUNNING_DIAN_HUO_ONE))
            {
                SoftPowerOff();
                return FAILED;
            }
            SetHydrgFanSpd(stDIANHUOING_1_ADJUST_PARAMETER[0].Ratio);
            printf("delay for second time airBlower adjust in the first time dianhuo begin!<---\r\n");
            if(Delay_BREAK == Delay_s(stDIANHUOING_1_ADJUST_PARAMETER[1].TimeForWaittingAdjust, PRERUNNING_DIAN_HUO_ONE))
            {
                SoftPowerOff();
                return FAILED;
            }
            SetHydrgFanSpd(stDIANHUOING_1_ADJUST_PARAMETER[1].Ratio);
            printf("delay for third time airBlower adjust in the first time dianhuo begin!<---\r\n");
            if(Delay_BREAK == Delay_s(stDIANHUOING_1_ADJUST_PARAMETER[2].TimeForWaittingAdjust, PRERUNNING_DIAN_HUO_ONE))
            {
                SoftPowerOff();
                return FAILED;
            }
            SetHydrgFanSpd(stDIANHUOING_1_ADJUST_PARAMETER[2].Ratio);
            m_FireTemp = GetFireTemp();
    //      printf("firetemp %f, dianhuo temp check table %f<----\r\n",m_FireTemp,m_DianHuoCheckTable1 );
            if(m_FireTemp >= m_DianHuoCheckTable1)
            {
                m_enDIAN_HUO_CHECK_STATU = PASS;
                break;
            }
            if((i == (maxtrytime - 1)) && (m_enDIAN_HUO_CHECK_STATU != PASS))
            {
                m_enDIAN_HUO_CHECK_STATU = FAILED;
                SetRunningStatus(KEEPINGWARM);
                MagneticValve1OFF;
                HeaterOFF;
            }
        }
    */
//  if(PASS == m_enDIAN_HUO_CHECK_STATU)
//  {
    g_u16StartRemainSecond = 15 * 60;
    m_stSYSTEM_TIME_RECORD_FOR_TEMP_CHECK = GetSystemTime();

    do {
        m_stCURRENT_SYSTEM_TIME = GetSystemTime();

//          m_RefromRoomTemp = GetRefromRoomTemp();
//          printf("Waitting for the reformroom temp up to %f or upmachine command to goto next step!<---\r\n", m_GoToNextStepTempTable1);
//          printf("reformroomtemp %f, gotonextstep table %f! AheadRunningFlag %d !<---\r\n",m_RefromRoomTemp,m_GoToNextStepTempTable1,GetAheadRunningFlag());
        if//(m_RefromRoomTemp >= m_GoToNextStepTempTable1)
//              ||
        (GetAheadRunningFlag() == YES) {
            SetAheadRunningFlag(NO);
            MagneticValve1OFF;
            m_enDIAN_HUO_CHECK_STATU = PASS;
            break;
        }

        if((((m_stCURRENT_SYSTEM_TIME.hour - m_stSYSTEM_TIME_RECORD_FOR_TEMP_CHECK.hour) * 60
                + m_stCURRENT_SYSTEM_TIME.minute - m_stSYSTEM_TIME_RECORD_FOR_TEMP_CHECK.minute) * 60
                + m_stCURRENT_SYSTEM_TIME.second - m_stSYSTEM_TIME_RECORD_FOR_TEMP_CHECK.second)
                >= 1) { //����ָ���¶Ȼ��ֶ���ǰ����
            g_u16StartRemainSecond--;
            m_stSYSTEM_TIME_RECORD_FOR_TEMP_CHECK = m_stCURRENT_SYSTEM_TIME;

            if((g_u16StartRemainSecond == 0) || (g_u16StartRemainSecond >= 60000)) { //��ֹ�����Լ�ʱԽ���쳣
                MagneticValve1OFF;
                m_enDIAN_HUO_CHECK_STATU = PASS;
                break;//return PASS;
            }

            //������������������1���Ӱ�--810��5s��10
            m_u8HydrgFanCtrlSpd = GetHydrgFanCtrlSpd();

            if(g_u16StartRemainSecond <= 810) {
                if(g_u16StartRemainSecond % 5 == 0) {
                        if(NO == m_u8HydrgFanSpeedUpFirstFinishFlag){
                        m_u8HydrgFanCtrlSpd = GetHydrgFanCtrlSpd();
                        if(m_u8HydrgFanCtrlSpd < 80) {//50
                            HydrgFanSpdInc();
                        }else{
                            m_u8HydrgFanSpeedUpFirstFinishFlag = YES;
                        }
                    }
                }

#ifdef FAN_SPEED_INC_MORE    //2���Ӱ�������μ���--750         

                if(g_u16StartRemainSecond <= 750) {
                    if(g_u16StartRemainSecond % 5 == 0) {
                        if(NO == m_u8HydrgFanSpeedUpSecondFinishFlag){
                            m_u8HydrgFanCtrlSpd = GetHydrgFanCtrlSpd();
                            if(m_u8HydrgFanCtrlSpd < 80) {//90
                                HydrgFanSpdInc();
                            }else{
                                m_u8HydrgFanSpeedUpSecondFinishFlag = YES;
                            }
                        }
                    }
                }

#endif
            }
        }
                if((GetRunningStatus() != PRERUNNING_DIAN_HUO_ONE)) {
            m_enDIAN_HUO_CHECK_STATU = FAILED;
            SoftPowerOff();//����ֹͣ
//              m_enDIAN_HUO_CHECK_STATU = FAILED;
            break;
        }
    } while(1);

    return m_enDIAN_HUO_CHECK_STATU;
}



DIAN_HUO_CHECK_STATU_Typedef DianHuoSecondTimeCheck(float m_DianHuoCheckTable2, float m_GoToNextStepTempTable2, uint8_t maxtrytime, uint8_t m_CheckDelayTimeFlag)
{
//  uint8_t i;
//  DIAN_HUO_CHECK_STATU_Typedef m_enDIAN_HUO_CHECK_STATU;

//  printf("dianhuo second time!<--\r\n");

    MagneticValve2ON;
    SetHydrgPumpSpd(PUMP_PRESSURE_OUTPUT[1]);
    SetHydrgFanSpd(40);

    IgniterON;
    TIM2_ForIgniteStart();
//  if(Delay_BREAK == Delay_s(120,PRERUNNING_DIAN_HUO_TWO))
//  {
//      SoftPowerOff();
//      return FAILED;
//  }
//  IgniterOFF;

    /*  for(i = 0; i < maxtrytime; i++)
        {
    //      printf("the %d try time during the second time dianhuo!<----\r\n", i + 1);
            IgniterON;
            TIM2_ForIgniteStart();
    //      printf("delay for first time airBlower adjust in the second time dianhuo begin!<---\r\n");
            if(Delay_BREAK == Delay_s(stDIANHUOING_2_ADJUST_PARAMETER[0].TimeForWaittingAdjust, PRERUNNING_DIAN_HUO_TWO))
            {
                SoftPowerOff();
                return FAILED;
            }
            SetHydrgFanSpd(stDIANHUOING_2_ADJUST_PARAMETER[0].Ratio);
    //      printf("delay for second time airBlower adjust in the second time dianhuo begin!<---\r\n");
            if(Delay_BREAK == Delay_s(stDIANHUOING_2_ADJUST_PARAMETER[1].TimeForWaittingAdjust, PRERUNNING_DIAN_HUO_TWO))
            {
                SoftPowerOff();
                return FAILED;
            }
            SetHydrgFanSpd(stDIANHUOING_2_ADJUST_PARAMETER[1].Ratio);
    //      printf("firetemp %f, dianhuo temp check table %f<-----\r\n",GetFireTemp(),m_DianHuoCheckTable2 );
            if(GetFireTemp() >= m_DianHuoCheckTable2)
            {
    //          SetHydrgFanSpd(200);
                m_enDIAN_HUO_CHECK_STATU = PASS;
                break;
            }
            if((i == maxtrytime - 1) && (m_enDIAN_HUO_CHECK_STATU != PASS))
            {
                MagneticValve2OFF;
                m_enDIAN_HUO_CHECK_STATU = FAILED;
                SetRunningStatus(KEEPINGWARM);
            }
        }*/
    return PASS;//m_enDIAN_HUO_CHECK_STATU;
}



u16 GetStartRemainSencond(void)
{
    return g_u16StartRemainSecond;
}

