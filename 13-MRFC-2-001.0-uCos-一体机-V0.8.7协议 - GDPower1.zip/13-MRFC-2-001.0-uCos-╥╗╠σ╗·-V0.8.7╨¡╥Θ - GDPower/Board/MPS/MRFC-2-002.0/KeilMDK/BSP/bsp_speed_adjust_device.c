/*
***************************************************************************************************
*                                         APPLICATION CODE
*
*                      (c) Copyright 2016; Guangdong ENECO Science And Technology Co.,Ltd
*
*               All rights reserved.  Protected by international copyright laws.
*               Knowledge of the source code may NOT be used without authorization.
***************************************************************************************************
*/
/*
***************************************************************************************************
* Filename      : bsp_speed_adjust_device.c
* Version       : V1.00
* Programmer(s) : JasonFan
***************************************************************************************************
*/
/*
***************************************************************************************************
*                                             INCLUDE FILES
***************************************************************************************************
*/
#define  BSP_ANA_SENSOR_MODULE
#include <bsp.h>
#include "math.h"
#include <includes.h>
#include "os_cfg_app.h"
#include <bsp_ana_sensor.h>
#include "app_system_real_time_parameters.h"
#include "app_analog_signal_monitor_task.h"
#include "bsp_speed_adjust_device.h"

/*
***************************************************************************************************
*                                       MICRO DEFINE
***************************************************************************************************
*/
#define SPEED_CONTROL_DEVICE_MANAGE_TASK_STK_SIZE       100

#define SPEED_SAMPLE_CHANNEL          3u//�ٶȷ����źŲ���ͨ����

#define FRONT_EDGE      0 //��������ǰ��
#define LAST_EDGE       1 //�����������
/*
***************************************************************************************************
*                                         OS-RELATED    VARIABLES
***************************************************************************************************
*/

OS_TCB      SpeedControlDevManageTaskTCB;
static      CPU_STK     SpdCtrlDevManageTaskStk[SPEED_CONTROL_DEVICE_MANAGE_TASK_STK_SIZE];

static      OS_TMR      PumpSpdAdjustTmr;//����ƽ�����ڶ�ʱ��

static      OS_TMR      HydrogenFanSpdCycleDlyTimeAdjustTmr;//��������ʱ���ڶ�ʱ��
/*
***************************************************************************************************
*                                       LOCAL GLOBAL VARIABLES
***************************************************************************************************
*/
static  uint16_t    g_u16HydrogenFanExpectCtrlSpd = 0;
static  uint16_t    g_u16HydrogenFanCurrentCtrlSpd = 0;

static  uint16_t    g_u16PumpExpectCtrlSpd = 0;
static  uint16_t    g_u16PumpCurrentCtrlSpd = 0;
static  uint16_t    g_u16PumpAdjAcceleratedSpdVal = 0;

static  uint16_t    g_u16StackFanCtlSpd = 0;

static  SWITCH_TYPE_VARIABLE_Typedef g_eSpdCaptureWorkSwitch[3] = {OFF, OFF, OFF}; //3·ͨ����⿪��
static  float g_fSpdCaptureFrequency[SPEED_SAMPLE_CHANNEL] = {0.0, 0.0, 0.0}; //��Ӧ���ͨ��������Ƶ����

static  uint16_t g_u16SpdCaptureEdgeNum[3] = {0, 0, 0}; //����ͨ�������жϴ���
static  uint16_t g_u16SpeedCaptureValue[3][2] = {0}; //����ͨ�������ڵ�һ�ν����жϺ����һ�ν����жϵļ���ֵ

/*
***************************************************************************************************
*                                         FUNCTION PROTOTYPES
***************************************************************************************************
*/
static void HydrogenFanSpdCycleDlyAdjCallBack(OS_TMR *p_tmr, void *p_arg);

static void PumpAdjustCallBack(OS_TMR *p_tmr, void *p_arg);

static void SpeedControlDevManageTask(void);
/*
***************************************************************************************************
*                              SpeedControlDevManageTaskCreate()
*
* Description : increase the pump speed a grade.
*
* Arguments   : none.
*
* Returns     : none
*
* Notes       : the actual speed grade whole number is 2000.
***************************************************************************************************
*/
void SpeedControlDevManageTaskCreate(void)
{
    OS_ERR  err;

    OSTaskCreate((OS_TCB *)&SpeedControlDevManageTaskTCB,
                 (CPU_CHAR *)"Speed Monitor task",
                 (OS_TASK_PTR) SpeedControlDevManageTask,
                 (void *) 0,
                 (OS_PRIO) SPEED_CONTROL_DEVICE_MANAGE_TASK_PRIO,
                 (CPU_STK *)&SpdCtrlDevManageTaskStk[0],
                 (CPU_STK_SIZE) SPEED_CONTROL_DEVICE_MANAGE_TASK_STK_SIZE / 10,
                 (CPU_STK_SIZE) SPEED_CONTROL_DEVICE_MANAGE_TASK_STK_SIZE,
                 (OS_MSG_QTY) 5u,
                 (OS_TICK) 0u,
                 (void *) 0,
                 (OS_OPT)(OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR),
                 (OS_ERR *)&err);
    APP_TRACE_DEBUG(("Created Speed Monitor task, and err code is %d...\r\n", err));
}

/*
***************************************************************************************************
*                                         SpeedControlDevManageTask()
*
* Description : increase the pump speed a grade.
*
* Arguments   : none.
*
* Returns     : none
*
* Notes       : the actual speed grade whole number is 2000.
***************************************************************************************************
*/
static void SpeedControlDevManageTask(void)
{
    OS_ERR      err;

    OSTaskSuspend(NULL, &err);

    while(DEF_TRUE) {
        OSTimeDlyHMSM(0, 0, 0, 500,
                      OS_OPT_TIME_HMSM_STRICT,
                      &err);
//        APP_TRACE_INFO(("g_EnableChannelNum: %d...\n\r\n\r", g_EnableChannelNum));
//        APP_TRACE_INFO(("TIM1CHX_CAPTURE_STA[PUMP_SPD_MONITOR]: %X...\n\r", TIM1CHX_CAPTURE_STA[PUMP_SPD_MONITOR]));
//        APP_TRACE_INFO(("TIM1CHX_CAPTURE_STA[HYDROGEN_FAN_SPD_MONITOR]: %X...\n\r", TIM1CHX_CAPTURE_STA[HYDROGEN_FAN_SPD_MONITOR]));
//        APP_TRACE_INFO(("TIM1CHX_CAPTURE_STA[STACK_FAN_SPD_MONITOR]: %X...\n\r\n\r", TIM1CHX_CAPTURE_STA[STACK_FAN_SPD_MONITOR]));
    }
}
/*
***************************************************************************************************
*                                         PumpSpdInc()
*
* Description : increase the pump speed a grade.
*
* Arguments   : none.
*
* Returns     : none
*
* Notes       : the speed grade whole number is 2000.
***************************************************************************************************
*/
void PumpSpdInc()
{
    uint16_t u16PumpCtlSpd;
    u16PumpCtlSpd = GetPumpCurrentCtrlSpd();

    if(u16PumpCtlSpd >= 1990) {
        u16PumpCtlSpd = 2000;
    } else {
        u16PumpCtlSpd += 10;
    }

    SetPumpCurrentCtrlSpd(u16PumpCtlSpd);
}

/*
***************************************************************************************************
*                                         PumpSpdDec()
*
* Description : decrease the pump speed a grade.
*
* Arguments   : none.
*
* Returns     : none
*
* Notes       : the speed grade whole number is 2000.
***************************************************************************************************
*/
void PumpSpdDec()
{
    uint16_t u16PumpCtlSpd;
    u16PumpCtlSpd = GetPumpCurrentCtrlSpd();

    if(u16PumpCtlSpd < 10) {
        u16PumpCtlSpd = 0;
    } else {
        u16PumpCtlSpd -= 10;
    }

    SetPumpCurrentCtrlSpd(u16PumpCtlSpd);
}

/*
***************************************************************************************************
*                                         GetPumpCurrentCtrlSpd()
*
* Description : get the pump speed grade number.
*
* Arguments   : none.
*
* Returns     : the pump speed grade number.
*
* Notes       : the speed grade whole number is 2000.
***************************************************************************************************
*/
uint16_t GetPumpCurrentCtrlSpd(void)
{
    return g_u16PumpCurrentCtrlSpd;
}

uint16_t GetPumpExpectCtrlSpd(void)
{
    return g_u16PumpExpectCtrlSpd;
}
/*
***************************************************************************************************
*                                         SetPumpCurrentCtrlSpd()
*
* Description : set the pump speed grade.
*
* Arguments   : the expected pump speed.
*
* Returns     : none.
*
* Notes       : the speed grade whole number is 2000.
***************************************************************************************************
*/
void SetPumpCurrentCtrlSpd(uint16_t i_u16NewSpd)
{
    CPU_SR_ALLOC();
    CPU_CRITICAL_ENTER();
    g_u16PumpCurrentCtrlSpd = i_u16NewSpd;
    BSP_SetPumpSpd(i_u16NewSpd);
    CPU_CRITICAL_EXIT();
}

/*
***************************************************************************************************
*                            SetPumpExpectSpdSmoothly()
*
* Description : Control the speed of the pump smoothly.
*
* Argument(s) : i_u16ExpectPumpSpdValue:Expect Speed.
*               i_u8SmoothlyControlTimeDly:Adjust pump Delay Time >= 0;if i_u8AdjustTimeDly = 0,set immediately.
*
* Return(s)   : none.
*
* Caller(s)   : none.
*
* Note(s)     : the actual speed grade whole number is 2000.
***************************************************************************************************
*/
void SetPumpExpectSpdSmoothly(u16 i_u16ExpectPumpSpdValue, u8 i_u8SmoothlyControlTimeDly)
{
    OS_ERR err;
    uint16_t m_u16PumpSpdDiffValue = 0;

    OSTmrDel(&PumpSpdAdjustTmr, &err);//���ö�ʱ��״̬

    if(i_u8SmoothlyControlTimeDly > 0) { //��Ҫ�ٶ�ƽ������
        if(i_u16ExpectPumpSpdValue != g_u16PumpExpectCtrlSpd){//�����µ������ٶ�
            g_u16PumpExpectCtrlSpd = i_u16ExpectPumpSpdValue;
        }
        
        if(g_u16PumpCurrentCtrlSpd != g_u16PumpExpectCtrlSpd) {
            m_u16PumpSpdDiffValue = abs(g_u16PumpExpectCtrlSpd - g_u16PumpCurrentCtrlSpd);
        }
        
        /*���ٶȼ���*/
        g_u16PumpAdjAcceleratedSpdVal = m_u16PumpSpdDiffValue / 2 / i_u8SmoothlyControlTimeDly;
        
        OSTmrCreate((OS_TMR *)&PumpSpdAdjustTmr,
                    (CPU_CHAR *)"Pump Speed Adjust Timer",
                    (OS_TICK)0,
                    (OS_TICK) OS_CFG_TMR_TASK_RATE_HZ / 2,      /* control cycle 0.5s */
                    (OS_OPT)OS_OPT_TMR_PERIODIC,
                    (OS_TMR_CALLBACK_PTR)PumpAdjustCallBack,
                    (void *)0,
                    (OS_ERR *)&err);

        if(err == OS_ERR_NONE) {
            OSTmrStart(&PumpSpdAdjustTmr, &err);
        }
    } else {
        SetPumpCurrentCtrlSpd(i_u16ExpectPumpSpdValue);
    }
}
/*
***************************************************************************************************
*                            PumpAdjustCallBack()
*
* Description : when PumpSpdAdjustTmr time out that call back function.
*
* Argument(s) : none.
*
* Return(s)   : none.
*
* Caller(s)   : Application.
*
* Note(s)     : none.
***************************************************************************************************
*/
static void PumpAdjustCallBack(OS_TMR *p_tmr, void *p_arg)
{	
	OS_ERR err;
    uint16_t u16PumpCurrentCtlSpd = 0;

    u16PumpCurrentCtlSpd = GetPumpCurrentCtrlSpd();

    if(u16PumpCurrentCtlSpd != GetPumpExpectCtrlSpd()) {
        if(u16PumpCurrentCtlSpd > GetPumpExpectCtrlSpd()) {
            if(u16PumpCurrentCtlSpd > g_u16PumpAdjAcceleratedSpdVal){//��ֹ�����
                u16PumpCurrentCtlSpd -= g_u16PumpAdjAcceleratedSpdVal;
            }else{
                u16PumpCurrentCtlSpd = 0;
                BSP_LqdValve2_PwrOff();//��ʱ�ر����Źط�
            }
        } else {
            u16PumpCurrentCtlSpd += g_u16PumpAdjAcceleratedSpdVal;
            if(u16PumpCurrentCtlSpd >= g_u16PumpExpectCtrlSpd){
                u16PumpCurrentCtlSpd = g_u16PumpExpectCtrlSpd;
            }
        }
        SetPumpCurrentCtrlSpd(u16PumpCurrentCtlSpd);
    } else {
        OSTmrDel(&PumpSpdAdjustTmr, &err);
    }
}
/*
***************************************************************************************************
*                                         HydrogenFanCtrSpdInc()
*
* Description : increase the hydrogen fan speed a grade.
*
* Arguments   : none.
*
* Returns     : none
*
* Notes       : the speed grade whole number is 2000.
***************************************************************************************************
*/
void HydrogenFanCtrSpdInc()
{
    uint16_t u16HydrgFanCtlSpd;
    u16HydrgFanCtlSpd = GetHydrgFanCurrentCtlSpd();

    if(u16HydrgFanCtlSpd >= 1900) {
        u16HydrgFanCtlSpd = 2000;
    } else {
        u16HydrgFanCtlSpd += 100;
    }

    SetHydrogenFanCtrlSpd(u16HydrgFanCtlSpd);
}

/*
***************************************************************************************************
*                                         HydrogenFanCtrSpdDec()
*
* Description : decrease the hydrogen fan speed a grade.
*
* Arguments   : none.
*
* Returns     : none
*
* Notes       : the speed grade whole number is 2000.
***************************************************************************************************
*/
void HydrogenFanCtrSpdDec()
{
    uint16_t u16HydrgFanCtlSpd;
    u16HydrgFanCtlSpd = GetHydrgFanCurrentCtlSpd();

    if(u16HydrgFanCtlSpd < 100) {
        u16HydrgFanCtlSpd = 0;
    } else {
        u16HydrgFanCtlSpd -= 100;
    }

    SetHydrogenFanCtrlSpd(u16HydrgFanCtlSpd);
}

/*
***************************************************************************************************
*                               GetHydrgFanCurrentCtlSpd()
*
* Description : get the hydrogen fan speed grade number.
*
* Arguments   : none.
*
* Returns     : the hydrogen fan speed grade number.
*
* Notes       : the speed grade whole number is 2000.
***************************************************************************************************
*/
uint16_t GetHydrgFanCurrentCtlSpd(void)
{
    return g_u16HydrogenFanCurrentCtrlSpd;
}

uint16_t GetHydrgFanExpectCtlSpd(void)
{
    return g_u16HydrogenFanExpectCtrlSpd;
}

/*
***************************************************************************************************
*                                         SetHydrogenFanCtrlSpd()
*
* Description : set the hydrogen fan speed grade.
*
* Arguments   : the expected hydrogen fan speed.
*
* Returns     : none.
*
* Notes       : the speed grade whole number is 2000.
***************************************************************************************************
*/
void SetHydrogenFanCtrlSpd(uint16_t i_u16NewSpd)
{
    CPU_SR_ALLOC();
    CPU_CRITICAL_ENTER();
    g_u16HydrogenFanCurrentCtrlSpd = i_u16NewSpd;
    BSP_SetHydrgFanSpd(i_u16NewSpd);
    CPU_CRITICAL_EXIT();
}

/*
***************************************************************************************************
*                                         SetHydrogenFanCtrlSpdSmoothly()
*
* Description : Delay for a period of time to set the hydrogen fan speed.
*
* Arguments   : i_u8StartDlyAdjTime:start adjust delay time.
*               i_u8DelayTime:Adjust the cycle time delay(s),if i_u8DelayTime =0,set immediately.
*               i_u16ExpectSpdValue:the expected hydrogen fan speed.
*
* Returns     : none.
*
* Notes       : the actual speed grade whole number is 2000.
***************************************************************************************************
*/

void SetHydrogenFanCtrlSpdSmoothly(uint16_t i_u16CurrentSpdVal, uint8_t i_u8FirstDlyAdjTime, uint8_t i_u8CycleDlyAdjTime, uint16_t i_u16ExpSpdVal)
{
    OS_ERR err;

    OSTmrDel(&HydrogenFanSpdCycleDlyTimeAdjustTmr, &err);//���ö�ʱ��״̬
    g_u16HydrogenFanExpectCtrlSpd = i_u16ExpSpdVal ;

    if((i_u8FirstDlyAdjTime > 0) || (i_u8CycleDlyAdjTime > 0)) {
        OSTmrCreate((OS_TMR *)&HydrogenFanSpdCycleDlyTimeAdjustTmr,
                    (CPU_CHAR *)"Hydrg fan Speed cycle Delay Adjust Timer",
                    (OS_TICK)i_u8FirstDlyAdjTime * OS_CFG_TMR_TASK_RATE_HZ,//�״���ʱdly(s)
                    (OS_TICK)i_u8CycleDlyAdjTime * OS_CFG_TMR_TASK_RATE_HZ,//������ʱcycle(s)
                    (OS_OPT)OS_OPT_TMR_PERIODIC,
                    (OS_TMR_CALLBACK_PTR)HydrogenFanSpdCycleDlyAdjCallBack,
                    (void *)0,
                    (OS_ERR *)&err);
                    
         if(err == OS_ERR_NONE) {
            OSTmrStart(&HydrogenFanSpdCycleDlyTimeAdjustTmr, &err);   
        }          
    } else {
        SetHydrogenFanCtrlSpd(g_u16HydrogenFanExpectCtrlSpd);
    }  
    SetHydrogenFanCtrlSpd(i_u16CurrentSpdVal);
}
/*
***************************************************************************************************
*                            HydrogenFanSpdCycleDlyAdjCallBack()
*
* Description : when HydrogenFanSpdCycleDlyTimeAdjustTmr time out that call back function.
*
* Argument(s) : none.
*
* Return(s)   : none.
*
* Note(s)     : none.
***************************************************************************************************
*/
static void HydrogenFanSpdCycleDlyAdjCallBack(OS_TMR *p_tmr, void *p_arg)
{
    OS_ERR err;

    if(g_u16HydrogenFanCurrentCtrlSpd != g_u16HydrogenFanExpectCtrlSpd) {
        if(g_u16HydrogenFanCurrentCtrlSpd < g_u16HydrogenFanExpectCtrlSpd) {
            HydrogenFanCtrSpdInc();
        } else {
            HydrogenFanCtrSpdDec();
        }
    } else {
        OSTmrDel(&HydrogenFanSpdCycleDlyTimeAdjustTmr, &err);
    }
}
/*
***************************************************************************************************
*                                         StackFanSpdInc()
*
* Description : increase the stack fan speed a grade.
*
* Arguments   : none.
*
* Returns     : none
*
* Notes       : the speed grade whole number is 200.
***************************************************************************************************
*/
void StackFanSpdInc()
{
    uint16_t u16StackFanCtlSpd;
    u16StackFanCtlSpd = GetStackFanCtlSpd();

    if(u16StackFanCtlSpd >= 1900) {
        u16StackFanCtlSpd = 2000;
    } else {
        u16StackFanCtlSpd += 100;
    }

    SetStackFanCtrlSpd(u16StackFanCtlSpd);
}

/*
***************************************************************************************************
*                                         StackFanSpdDec()
*
* Description : decrease the stack fan speed a grade.
*
* Arguments   : none.
*
* Returns     : none
*
* Notes       : the speed grade whole number is 200.
***************************************************************************************************
*/
void StackFanSpdDec()
{
    uint16_t u16StackFanCtlSpd;
    u16StackFanCtlSpd = GetStackFanCtlSpd();

    if(u16StackFanCtlSpd < 100) {
        u16StackFanCtlSpd = 0;
    } else {
        u16StackFanCtlSpd -= 100;
    }

    SetStackFanCtrlSpd(u16StackFanCtlSpd);
}


/*
***************************************************************************************************
*                           GetStackFanCtlSpd()
*
* Description : get the stack fan speed grade number.
*
* Arguments   : none.
*
* Returns     : the stack fan speed grade number.
*
* Notes       : the speed grade whole number is 200.
***************************************************************************************************
*/
uint16_t GetStackFanCtlSpd(void)
{
    return g_u16StackFanCtlSpd;
}
/*
***************************************************************************************************
*                                         SetStackFanCtrlSpd()
*
* Description : set the stack fan speed grade.
*
* Arguments   : the expected stack fan speed.
*
* Returns     : none.
*
* Notes       : the speed grade whole number is 2000.
***************************************************************************************************
*/
void SetStackFanCtrlSpd(uint16_t i_u16NewSpd)
{
    CPU_SR_ALLOC();
    CPU_CRITICAL_ENTER();
    g_u16StackFanCtlSpd = i_u16NewSpd;
    BSP_SetStackFanSpd(i_u16NewSpd);
    CPU_CRITICAL_EXIT();
}

/*
***************************************************************************************************
*                                         ResetSpdCaptureValue()
*
* Description : set the stack fan speed grade.
*
* Arguments   : the expected stack fan speed.
*
* Returns     : none.
*
* Notes       : the speed grade whole number is 2000.
***************************************************************************************************
*/
void ResetSpdCaptureValue(uint8_t i_CaptureChannel)
{
    g_fSpdCaptureFrequency[i_CaptureChannel] = 0;
    g_u16SpdCaptureEdgeNum[i_CaptureChannel] = 0;
    g_u16SpeedCaptureValue[i_CaptureChannel][LAST_EDGE] = 0;
    g_u16SpeedCaptureValue[i_CaptureChannel][FRONT_EDGE] = 0;
}

/*
********************************************************************************************************
*                                     BSP_DevSpdCaptureFinishedHandler()
*
* Description : �ٶȿ����豸�ٶ����벶������жϷ�����.
*
* Argument(s) : none.
*
* Return(s)   : none.
*
* Caller(s)   : none.
*
* Note(s)     : ��������+����.
********************************************************************************************************
*/
void BSP_DevSpdCaptureFinishedHandler(void)
{
    /*���벶��״̬:bit15-����ʹ��λ��bit14-������״̬λ,,����λ��������ؼ���λ*/
    static uint16_t TIM1CHX_CAPTURE_STA[3] = {0, 0, 0};
    static uint8_t  stEnableChannelNum = 0;//ͨ���л�����,ÿ0.5���л�һ��

    if(TIM_GetITStatus(TIM1, TIM_IT_CC1) != RESET) { //����ˮ��ת������
        if(g_eSpdCaptureWorkSwitch[PUMP_SPD_MONITOR] == ON) {
            if(TIM1CHX_CAPTURE_STA[PUMP_SPD_MONITOR] & 0x8000) {

                TIM1CHX_CAPTURE_STA[PUMP_SPD_MONITOR]++;

                if(TIM1CHX_CAPTURE_STA[PUMP_SPD_MONITOR] & 0x4000) { //���ǵ�һ�ν����ж�
                    g_u16SpeedCaptureValue[PUMP_SPD_MONITOR][LAST_EDGE] = TIM_GetCapture1(TIM1);//���ϸ��¸ü���ֵ,ֱ����¼���������������һ�ν����жϵļ���ֵ
                } else {
                    TIM1CHX_CAPTURE_STA[PUMP_SPD_MONITOR] |= 0x4000;//����״β���ˮ��ת������
                    g_u16SpeedCaptureValue[PUMP_SPD_MONITOR][FRONT_EDGE] = TIM_GetCapture1(TIM1);//��¼��һ�εļ���ֵ
                }
            }
        } else {
            ResetSpdCaptureValue(PUMP_SPD_MONITOR);
        }

        TIM_ClearITPendingBit(TIM1, TIM_IT_CC1);
    } else if(TIM_GetITStatus(TIM1, TIM_IT_CC2) != RESET) { //����ˮ��ת������
        if(g_eSpdCaptureWorkSwitch[HYDROGEN_FAN_SPD_MONITOR] == ON) {
            if(TIM1CHX_CAPTURE_STA[HYDROGEN_FAN_SPD_MONITOR] & 0x8000) {

                TIM1CHX_CAPTURE_STA[HYDROGEN_FAN_SPD_MONITOR]++;

                if(TIM1CHX_CAPTURE_STA[HYDROGEN_FAN_SPD_MONITOR] & 0x4000) { //���ǵ�һ�ν����ж�
                    g_u16SpeedCaptureValue[HYDROGEN_FAN_SPD_MONITOR][LAST_EDGE] = TIM_GetCapture2(TIM1);
                } else {
                    TIM1CHX_CAPTURE_STA[HYDROGEN_FAN_SPD_MONITOR] |= 0x4000;
                    g_u16SpeedCaptureValue[HYDROGEN_FAN_SPD_MONITOR][FRONT_EDGE] = TIM_GetCapture2(TIM1);
                }
            }
        } else {
            ResetSpdCaptureValue(HYDROGEN_FAN_SPD_MONITOR);
        }

        TIM_ClearITPendingBit(TIM1, TIM_IT_CC2);
    } else if(TIM_GetITStatus(TIM1, TIM_IT_CC3) != RESET) { //���񵽵�ѷ��ת������
        if(g_eSpdCaptureWorkSwitch[STACK_FAN_SPD_MONITOR] == ON) {
            if(TIM1CHX_CAPTURE_STA[STACK_FAN_SPD_MONITOR] & 0x8000) {

                TIM1CHX_CAPTURE_STA[STACK_FAN_SPD_MONITOR]++;

                if(TIM1CHX_CAPTURE_STA[STACK_FAN_SPD_MONITOR] & 0x4000) {
                    g_u16SpeedCaptureValue[STACK_FAN_SPD_MONITOR][LAST_EDGE] = TIM_GetCapture3(TIM1);
                } else {
                    TIM1CHX_CAPTURE_STA[STACK_FAN_SPD_MONITOR] |= 0x4000;
                    g_u16SpeedCaptureValue[STACK_FAN_SPD_MONITOR][FRONT_EDGE] = TIM_GetCapture3(TIM1);
                }
            }
        } else {
            ResetSpdCaptureValue(STACK_FAN_SPD_MONITOR);
        }

        TIM_ClearITPendingBit(TIM1, TIM_IT_CC3);
    } else {
    }

    /*�����ж���ÿ0.5s�л�һ�β���ͨ��*/
    if(TIM_GetITStatus(TIM1, TIM_IT_Update) != RESET) {
        stEnableChannelNum++;

        if(stEnableChannelNum == 1) {

            if((TIM1CHX_CAPTURE_STA[PUMP_SPD_MONITOR] & 0x3FFF) != 0) {
                g_u16SpdCaptureEdgeNum[PUMP_SPD_MONITOR] = (TIM1CHX_CAPTURE_STA[PUMP_SPD_MONITOR] & 0x3FFF);//���沶����ش���
                g_u16SpeedCaptureValue[PUMP_SPD_MONITOR][FRONT_EDGE] = g_u16SpeedCaptureValue[PUMP_SPD_MONITOR][FRONT_EDGE];//���沶��ǰ�ؼ���ֵ
                g_u16SpeedCaptureValue[PUMP_SPD_MONITOR][LAST_EDGE] = g_u16SpeedCaptureValue[PUMP_SPD_MONITOR][LAST_EDGE];//���沶����ؼ���ֵ
            }

            TIM1CHX_CAPTURE_STA[PUMP_SPD_MONITOR] = 0;  //�رձ�����ͨ��������ղ�����ؼ���
            TIM_ITConfig(TIM1, TIM_IT_CC1, DISABLE);
            TIM1CHX_CAPTURE_STA[HYDROGEN_FAN_SPD_MONITOR] = 0x8000;   //������һͨ������
            TIM_ITConfig(TIM1, TIM_IT_CC2, ENABLE);
        } else if(stEnableChannelNum == 2) {

            if((TIM1CHX_CAPTURE_STA[HYDROGEN_FAN_SPD_MONITOR] & 0x3FFF) != 0) {
                g_u16SpdCaptureEdgeNum[HYDROGEN_FAN_SPD_MONITOR] = (TIM1CHX_CAPTURE_STA[HYDROGEN_FAN_SPD_MONITOR] & 0x3FFF);//���沶����ش���
                g_u16SpeedCaptureValue[HYDROGEN_FAN_SPD_MONITOR][FRONT_EDGE] = g_u16SpeedCaptureValue[HYDROGEN_FAN_SPD_MONITOR][FRONT_EDGE];
                g_u16SpeedCaptureValue[HYDROGEN_FAN_SPD_MONITOR][LAST_EDGE] = g_u16SpeedCaptureValue[HYDROGEN_FAN_SPD_MONITOR][LAST_EDGE];
            }

            TIM1CHX_CAPTURE_STA[HYDROGEN_FAN_SPD_MONITOR] = 0;  //�رձ�����ͨ��������ղ�����ؼ���
            TIM_ITConfig(TIM1, TIM_IT_CC2, DISABLE);
            TIM1CHX_CAPTURE_STA[STACK_FAN_SPD_MONITOR] = 0x8000;   //������һͨ������
            TIM_ITConfig(TIM1, TIM_IT_CC3, ENABLE);

        } else if(stEnableChannelNum == 3) {

            if((TIM1CHX_CAPTURE_STA[STACK_FAN_SPD_MONITOR] & 0x3FFF) != 0) {
                g_u16SpdCaptureEdgeNum[STACK_FAN_SPD_MONITOR] = (TIM1CHX_CAPTURE_STA[STACK_FAN_SPD_MONITOR] & 0x3FFF);//���沶����ش���
                g_u16SpeedCaptureValue[STACK_FAN_SPD_MONITOR][FRONT_EDGE] = g_u16SpeedCaptureValue[STACK_FAN_SPD_MONITOR][FRONT_EDGE];
                g_u16SpeedCaptureValue[STACK_FAN_SPD_MONITOR][LAST_EDGE] = g_u16SpeedCaptureValue[STACK_FAN_SPD_MONITOR][LAST_EDGE];
            }

            TIM1CHX_CAPTURE_STA[STACK_FAN_SPD_MONITOR] = 0;  //�رձ�����ͨ��������ղ�����ؼ���
            TIM_ITConfig(TIM1, TIM_IT_CC3, DISABLE);
            TIM1CHX_CAPTURE_STA[PUMP_SPD_MONITOR] = 0x8000;   //������һͨ������
            TIM_ITConfig(TIM1, TIM_IT_CC1, ENABLE);
            stEnableChannelNum = 0; //�ָ���ʼͨ��
        } else {}

        TIM_ClearITPendingBit(TIM1, TIM_IT_Update);
    }
}

/*
***************************************************************************************************
*                          GetHydrgFanFeedBackSpd()
*
* Description : get the hydrogen fan feed back speed grade number.
*
* Argument(s) : none.
*
* Return(s)   : none.
*
* Caller(s)   : Application.
*
* Note(s)     : �������ʾת��һȦ.
***************************************************************************************************
*/
uint16_t    GetPumpFeedBackSpd(void)
{
    /*2����ÿת��һ���ӵ������������->0.5 * 60 * 2 = 60 ,5000��ʱ���������ֵ*/
    g_fSpdCaptureFrequency[PUMP_SPD_MONITOR] = 60 * (((5000.0 - g_u16SpeedCaptureValue[PUMP_SPD_MONITOR][FRONT_EDGE] \
            + g_u16SpeedCaptureValue[PUMP_SPD_MONITOR][LAST_EDGE]) / 5000.0) + (g_u16SpdCaptureEdgeNum[PUMP_SPD_MONITOR] - 1));

    return (uint16_t)(g_fSpdCaptureFrequency[PUMP_SPD_MONITOR] * 0.33);//��λ��������ʾ������

}
/*
***************************************************************************************************
*                         GetHydrgFanFeedBackSpd()
*
* Description : get the hydrogen fan feed back speed grade number.
*
* Argument(s) : none.
*
* Return(s)   : none.
*
* Caller(s)   : Application.
*
* Note(s)     : none.
***************************************************************************************************
*/
uint16_t GetHydrgFanFeedBackSpd(void)
{
    g_fSpdCaptureFrequency[HYDROGEN_FAN_SPD_MONITOR] = 60 * (((5000.0 - g_u16SpeedCaptureValue[HYDROGEN_FAN_SPD_MONITOR][FRONT_EDGE] \
            + g_u16SpeedCaptureValue[HYDROGEN_FAN_SPD_MONITOR][LAST_EDGE]) / 5000.0) + (g_u16SpdCaptureEdgeNum[HYDROGEN_FAN_SPD_MONITOR] - 1));
    return (uint16_t)(g_fSpdCaptureFrequency[HYDROGEN_FAN_SPD_MONITOR] * 0.083);// 2000 / 24000
}

/*
***************************************************************************************************
*                        GetStackFanSpdFeedBack()
*
* Description : get the stack fan feed back speed grade number.
*
* Arguments   : none.
*
* Returns     : the stack fan speed grade number.
*
* Notes       : the speed grade whole number is 2000.
***************************************************************************************************
*/
uint16_t GetStackFanSpdFeedBack(void)
{
    g_fSpdCaptureFrequency[STACK_FAN_SPD_MONITOR] = 60 * (((5000.0 - g_u16SpeedCaptureValue[STACK_FAN_SPD_MONITOR][FRONT_EDGE] \
            + g_u16SpeedCaptureValue[STACK_FAN_SPD_MONITOR][LAST_EDGE]) / 5000.0) + (g_u16SpdCaptureEdgeNum[STACK_FAN_SPD_MONITOR] - 1));

    return (uint16_t)(g_fSpdCaptureFrequency[STACK_FAN_SPD_MONITOR]); 
}

/*
***************************************************************************************************
*                     SetSpdMonitorSwitch()
*
* Description : Turn on the running speed control device monitor.
*
* Arguments   : none.
*
* Returns     : none.
*
* Notes       : none.
***************************************************************************************************
*/
void SetSpdMonitorSwitch(SPEED_MONITOR_CHANNEL_Typedef i_SpdMonitorChannel)
{
    g_eSpdCaptureWorkSwitch[i_SpdMonitorChannel] = ON;

}
/*
***************************************************************************************************
*                     ResetSpdMonitorSwitch()
*
* Description : Turn off the running speed control device monitor.
*
* Arguments   : none.
*
* Returns     : none.
*
* Notes       : none.
***************************************************************************************************
*/
void ResetSpdMonitorSwitch(SPEED_MONITOR_CHANNEL_Typedef i_SpdMonitorChannel)
{
    g_eSpdCaptureWorkSwitch[i_SpdMonitorChannel] = OFF;
}

/******************* (C) COPYRIGHT 2016 Guangdong ENECO POWER *****END OF FILE****/
